package it.epicode.ewallet.listamovimenti;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface ListaMovimentiRepository extends CrudRepository<ListaMovimenti, Integer> {

	
	public List<ListaMovimenti> findByOperazione(String operazione);
	
	
	
}
