package it.epicode.ewallet.contocorrente;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface ContocorrenteRepository extends CrudRepository<Contocorrente, Integer> {
public List<Contocorrente> findByIban(String iban);
public List<Contocorrente> findByIntestatario(String intestatario);

}
