package it.epicode.ewallet.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Service;

import it.epicode.ewallet.DTO.CercaContoPerIdResponseDTO;
import it.epicode.ewallet.DTO.CercaContoPerIntestatarioResponseDTO;
import it.epicode.ewallet.DTO.CercaMovimentoPerOperazioneResponseDTO;
import it.epicode.ewallet.DTO.CercaTuttiIContiResponseDTO;
import it.epicode.ewallet.DTO.CercaTuttiIMovimentiResponseDTO;
import it.epicode.ewallet.DTO.InserisciContoRequestDTO;
import it.epicode.ewallet.DTO.ModificaMovimentoRequestDTO;
import it.epicode.ewallet.DTO.PrelevaRequestDTO;
import it.epicode.ewallet.contocorrente.Contocorrente;
import it.epicode.ewallet.contocorrente.ContocorrenteRepository;
import it.epicode.ewallet.listamovimenti.ListaMovimenti;
import it.epicode.ewallet.listamovimenti.ListaMovimentiRepository;


@Service
public class EwalletServices {
	@Autowired
	ContocorrenteRepository cp;
	@Autowired
	ListaMovimentiRepository rlp;


	public boolean inserisciConto(InserisciContoRequestDTO dto) {
		Contocorrente c = new Contocorrente();


		c.setData(dto.getData());
		c.setIban(dto.getIban());
		c.setIntestatario(dto.getIntestatario());
		c.setSaldo(dto.getSaldo());
		cp.save(c);
		return true;
	}


	public CercaTuttiIContiResponseDTO trovaTuttiIConti() {
		CercaTuttiIContiResponseDTO dto = new CercaTuttiIContiResponseDTO();
		List<Contocorrente> lc = (List)cp.findAll(); 
		if(lc.size()> 0) {
			dto.setContiTrovati(lc.size());
			dto.setElencoConti(lc);
			return dto;
		}
		else {
			new ResponseEntity("nessun conto trovato", HttpStatus.NOT_FOUND);
			return null;
		}

	}
 


	public boolean EliminaConto(int id) {
		if(cp.existsById(id)) {
			cp.deleteById(id);
			return true; 
		}
		else {
			return false;
		}
	}



	public ResponseEntity cercaContoPerIntestatario(String intestario) {
		CercaContoPerIntestatarioResponseDTO dto = new CercaContoPerIntestatarioResponseDTO();
		List<Contocorrente>lc = cp.findByIntestatario(intestario);
		if(lc.size()>0) {
			dto.setIntestatario(intestario);
			dto.setContiTrovati(lc.size());
			dto.setElencoConti(lc);
			return ResponseEntity.ok(dto);
		}
		else {
			return new ResponseEntity("nessun conto trovato", HttpStatus.NOT_FOUND);
		}

	}

	public CercaContoPerIdResponseDTO trovaContoPerId(int id) {
		CercaContoPerIdResponseDTO dto = new CercaContoPerIdResponseDTO();
		if(cp.existsById(id)) {
			dto.setContoTrovato(cp.findById(id).get());
			return dto;
		}
		else return null;
	}


	public ResponseEntity preleva(PrelevaRequestDTO dto) {
		if(cp.existsById(dto.getId())) {
			Contocorrente c = cp.findById(dto.getId()).get();
			if(c.getSaldo()>= dto.getImporto()) {
				c.setSaldo(c.getSaldo() - dto.getImporto());
				cp.save(c);
				ListaMovimenti lm = new ListaMovimenti();
				lm.setImporto(dto.getImporto());
				lm.setOperazione("Prelievo");
				lm.setContocorrente(c);
				rlp.save(lm);
				return ResponseEntity.ok("Prelievo riuscito");
			}
			else {
				return  new ResponseEntity("Prelievo non riuscito", HttpStatus.BAD_REQUEST);
			}
		}
		else {
			return  new ResponseEntity("conto non esistente", HttpStatus.BAD_REQUEST);
		}
	}

	
	
	public ResponseEntity versa(PrelevaRequestDTO dto) {
		if(cp.existsById(dto.getId())) {
			Contocorrente c = cp.findById(dto.getId()).get();
			if(c.getSaldo()>= 0) {
				c.setSaldo(c.getSaldo() + dto.getImporto());
				cp.save(c);
				ListaMovimenti lm = new ListaMovimenti();
				lm.setImporto(dto.getImporto());
				lm.setOperazione("Versamento");
				lm.setContocorrente(c);
				rlp.save(lm);
				return ResponseEntity.ok("Versamento riuscito");
			}
			else {
				return  new ResponseEntity("Versamento non riuscito", HttpStatus.BAD_REQUEST);
			}
		}
		else {
			return  new ResponseEntity("conto non esistente", HttpStatus.BAD_REQUEST);
		}


	}
	
	
	public boolean EliminaMovimento(int id) {
		if(rlp.existsById(id)) {
			rlp.deleteById(id);
			return true; 
		}
		else {
			return false;
		}
	}
	
	public CercaTuttiIMovimentiResponseDTO trovaTuttiIMovimenti() {
		CercaTuttiIMovimentiResponseDTO dto = new CercaTuttiIMovimentiResponseDTO();	
		List<ListaMovimenti> lm = (List)rlp.findAll(); 
		if(lm.size()> 0) {
			dto.setMovimentiTrovati(lm.size());
			dto.setElencoMovimenti(lm);
			return dto;
		}
		else {
			new ResponseEntity("nessun Movimento trovato", HttpStatus.NOT_FOUND);
			return null;
		}

	}
	
	
	public ResponseEntity cercaMovimentoPerOperazione(String operazione) {
		CercaMovimentoPerOperazioneResponseDTO dto = new CercaMovimentoPerOperazioneResponseDTO();
		List<ListaMovimenti>lm = rlp.findByOperazione(operazione);
		if(lm.size()>0) {
			dto.setElencoMovimenti(lm);
			dto.setMovimentiTrovati(lm.size());
			dto.setOperazione(operazione);
			return ResponseEntity.ok(dto);
		}
		else {
			return new ResponseEntity("nessun Movimento trovato", HttpStatus.NOT_FOUND);
		}

	}
	

	public boolean ModificaMovimento(ModificaMovimentoRequestDTO dto) {
		if(rlp.existsById(dto.getId())) {
			ListaMovimenti m = rlp.findById(dto.getId()).get();
			m.setImporto(dto.getImporto());
			m.setOperazione(dto.getOperazione());
			rlp.save(m);
			return true;


		}
		else {
			return false;
		}
	}
}




