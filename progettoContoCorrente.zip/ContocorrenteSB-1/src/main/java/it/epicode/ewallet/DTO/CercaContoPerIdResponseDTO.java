package it.epicode.ewallet.DTO;

import it.epicode.ewallet.contocorrente.Contocorrente;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CercaContoPerIdResponseDTO {

	
	private Contocorrente contoTrovato;
}
