package it.epicode.ewallet.listamovimenti;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import it.epicode.ewallet.DTO.ModificaMovimentoRequestDTO;
import it.epicode.ewallet.services.EwalletServices;


@RestController
@RequestMapping("/ewalletMovimenti")
public class ListaMovimentiController {
	@Autowired
	EwalletServices es;

	@GetMapping ("/tuttiMovimenti")
	public ResponseEntity tuttiIMovimenti() {
		return ResponseEntity.ok(es.trovaTuttiIMovimenti());
	}

	@DeleteMapping(path = "/eliminaMovimento/{id}", produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity cancellaMovimento(@PathVariable ("id") int id ) {
		if(es.EliminaMovimento(id)) {
			return ResponseEntity.ok("Movimento eliminato");}
		else {
			return  new ResponseEntity("Movimento non trovato ", HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping(path ="/cercaPerOperazione/{operazione}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity cercaPerIntestatario(@PathVariable("operazione") String operazione) {
		return es.cercaMovimentoPerOperazione(operazione);


	}
	
	@PutMapping( produces = MediaType.TEXT_PLAIN_VALUE, path = "/modificaMovimento/{id}")
	public ResponseEntity modificaListaMovimenti(@Valid @PathVariable("id")int id,@RequestBody ModificaMovimentoRequestDTO dto, BindingResult errori) {

		if(errori.hasErrors()) {
			List<String> descrizioneDiErrore = new ArrayList<String>();
			for(ObjectError e : errori.getAllErrors()) {
				descrizioneDiErrore.add(e.getDefaultMessage());
			}
			return new ResponseEntity(descrizioneDiErrore , HttpStatus.BAD_REQUEST);

		}
		if(es.ModificaMovimento(dto)) {
			return ResponseEntity.ok("Movimento modificato");}
		else {return new ResponseEntity("il movimento non esiste", HttpStatus.NOT_FOUND);}

	}

}


