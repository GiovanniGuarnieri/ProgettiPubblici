package it.epicode.ewallet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContocorrenteSb1Application {

	public static void main(String[] args) {
		SpringApplication.run(ContocorrenteSb1Application.class, args);
	}

}
