package it.epicode.ewallet.DTO;

import javax.validation.constraints.NotBlank;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
public class ModificaMovimentoRequestDTO {
	@NotBlank(message = "il campo id deve essere obbligatorio")
	private int id;
	@NotBlank(message = "il campo operazione deve essere obbligatorio")
	private String operazione;
	@NotBlank(message = "il campo importo deve essere obbligatorio")
	private double importo;
	
}
