package it.epicode.ewallet.DTO;

import java.util.List;

import it.epicode.ewallet.listamovimenti.ListaMovimenti;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PrelevaRequestDTO {
private double importo;
int id;



}
