package it.epicode.ewallet.DTO;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InserisciContoRequestDTO {
	private String data;
	private String iban;
	private double saldo;
	private String intestatario;
}
