package it.epicode.ewallet.DTO;

import java.util.List;

import it.epicode.ewallet.contocorrente.Contocorrente;
import it.epicode.ewallet.listamovimenti.ListaMovimenti;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CercaTuttiIMovimentiResponseDTO {
	private int MovimentiTrovati;
	List<ListaMovimenti>elencoMovimenti;
	
}
