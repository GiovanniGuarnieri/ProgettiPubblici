package it.epicode.ewallet.contocorrente;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import it.epicode.ewallet.DTO.CercaContoPerIdResponseDTO;
import it.epicode.ewallet.DTO.InserisciContoRequestDTO;
import it.epicode.ewallet.DTO.PrelevaRequestDTO;
import it.epicode.ewallet.services.EwalletServices;






@RestController
@RequestMapping("/ewallet")
public class ContocorrenteController {
	@Autowired
	EwalletServices es;

	@PostMapping(path = "/inserisci" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisciConto(@Valid @RequestBody InserisciContoRequestDTO dto, BindingResult errori) {

		if(errori.hasErrors()) {
			List<String> descrizioneDiErrore = new ArrayList<String>();
			for(ObjectError e : errori.getAllErrors()) {
				descrizioneDiErrore.add(e.getDefaultMessage());
			}
			return new ResponseEntity(descrizioneDiErrore , HttpStatus.BAD_REQUEST);
		}
		if(es.inserisciConto(dto)) {
			return ResponseEntity.ok("conto inserito");}
		else {return new ResponseEntity("errore nell'inserimento", HttpStatus.FAILED_DEPENDENCY);}
	}
	
	
	
	@GetMapping ("/tuttiConti")
	public ResponseEntity tuttiIConti() {
		return ResponseEntity.ok(es.trovaTuttiIConti());
	}
	
	
	
	@DeleteMapping(path = "/eliminaConto/{id}", produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity cancellaConto(@PathVariable ("id") int id ) {
		if(es.EliminaConto(id)) {
			return ResponseEntity.ok("Conto eliminato");}
		else {
			return  new ResponseEntity("Conto non trovato ", HttpStatus.NOT_FOUND);
		}
	}
	
	
	@GetMapping(path ="/cercaPerIntestatario/{intestatario}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity cercaPerIntestatario(@PathVariable("intestatario") String iban) {
		return es.cercaContoPerIntestatario(iban);
	}
	@GetMapping(path ="/cercaPerId/{id}", produces =  MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity cercaPerId(@PathVariable("id") int id) {
		CercaContoPerIdResponseDTO cfr= es.trovaContoPerId(id);
		if(cfr!= null) {
			return ResponseEntity.ok(cfr);}
		else {
			return new ResponseEntity("nessun Conto trovato", HttpStatus.NOT_FOUND);
		}
	}
	@PutMapping(path ="/preleva", produces =  MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity preleva( @RequestBody PrelevaRequestDTO dto ) {
		return es.preleva(dto);
	}

	@PutMapping(path ="/versamento", produces =  MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity versamento( @RequestBody PrelevaRequestDTO dto ) {
		return es.versa(dto);
	}
	}
	
	
	
	
	
	

