package it.epicode.ewallet.DTO;

import java.util.List;


import it.epicode.ewallet.listamovimenti.ListaMovimenti;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CercaMovimentoPerOperazioneResponseDTO {
	private String operazione;
	private List<ListaMovimenti>elencoMovimenti;
	private int MovimentiTrovati;

}
