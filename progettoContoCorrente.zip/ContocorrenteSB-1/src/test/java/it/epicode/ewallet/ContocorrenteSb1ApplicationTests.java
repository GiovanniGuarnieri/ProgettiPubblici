package it.epicode.ewallet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContocorrenteSb1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
