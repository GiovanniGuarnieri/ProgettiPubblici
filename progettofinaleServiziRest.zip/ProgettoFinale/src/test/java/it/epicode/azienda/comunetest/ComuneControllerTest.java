package it.epicode.azienda.comunetest;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.azienda.BasicTests;
import it.epicode.azienda.dto.EliminaComuneRequestDTO;
import it.epicode.azienda.dto.InserisciComuneRequestDTO;
import it.epicode.azienda.dto.ModificaComuneRequestDTO;
import lombok.extern.slf4j.Slf4j;
@Slf4j
public class ComuneControllerTest extends BasicTests {

	@Override
	protected String getEntryPoint() {
		
		return "/comune";
	}
	
	@Test
	void getAllComuni() {
		log.info("================siamo nel test getAllComuni==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticomuni", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
	}
	@Test
	void getAllComuniKo() {
		log.info("================siamo nel test getAllComuniKo==================");
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutticomuni", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllComuniNotAuth() {
		log.info("================siamo nel test getAllComuniNotAuth==================");
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutticomuni", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllComuneProvinceNome() {
		log.info("================siamo nel test getAllComuneProvinceNome==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticomuninome/Na", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void getAllComuneProvinceNomeKo() {
		log.info("================siamo nel test getAllComuneProvinceNomeKo==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticomuninome/Na", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllComuneProvinceNomeNotFound() {
		log.info("================siamo nel test getAllComuneProvinceNomeNotFound==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticomuninome/", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void getAllComuneProvinceNomeNotAuth() {
		log.info("================siamo nel test getAllComuneProvinceNomeNotAuth==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticomuninome/na", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void inserisciComune() {
		log.info("================siamo nel test  inserisciComune==================");
		InserisciComuneRequestDTO dto = new InserisciComuneRequestDTO();
		dto.setCap("80021");
		dto.setNome("boh");
		dto.setSiglaProvincia("blAb");
		HttpEntity<	InserisciComuneRequestDTO>entity = new HttpEntity<	InserisciComuneRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/inseriscicomune",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
	}
	@Test
	void inserisciComuneKo() {
		log.info("================siamo nel test  inserisciComuneKo==================");
		InserisciComuneRequestDTO dto = new InserisciComuneRequestDTO();
		dto.setCap("80021");
		dto.setNome("boh");
		dto.setSiglaProvincia("NA");	
		HttpEntity<	InserisciComuneRequestDTO>entity = new HttpEntity<	InserisciComuneRequestDTO>(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/inseriscicomune",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
		
	}
	@Test
	void inserisciComuneNotAuth() {
		log.info("================siamo nel test  inserisciComuneNotAuth==================");
		InserisciComuneRequestDTO dto = new InserisciComuneRequestDTO();
		dto.setCap("80021");
		dto.setNome("boh");
		dto.setSiglaProvincia("NA");	
		HttpEntity<	InserisciComuneRequestDTO>entity = new HttpEntity<	InserisciComuneRequestDTO>(dto);
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/inseriscicomune",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
	}
	@Test
	void inserisciComuneNotFound() {
		log.info("================siamo nel test  inserisciComuneNotFound==================");
		InserisciComuneRequestDTO dto = new InserisciComuneRequestDTO();
		dto.setCap("80021");
		dto.setNome("boh");
		dto.setSiglaProvincia("notfound");	
		
		HttpEntity<	InserisciComuneRequestDTO>entity = new HttpEntity<	InserisciComuneRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/inseriscicomune",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
		
	}
	@Test
	void modificaComune() {
		log.info("================siamo nel test modificaComune==================");
		ModificaComuneRequestDTO dto = new ModificaComuneRequestDTO();
		dto.setId(2L);
		dto.setCap("8002");
		dto.setSiglaProvincia("blAb");
		dto.setNome("boh");
		
		HttpEntity<	ModificaComuneRequestDTO>entity = new HttpEntity<ModificaComuneRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificacomune",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
	}
	@Test
	void modificaComuneKo() {
		log.info("================siamo nel test modificaComuneKo==================");
		ModificaComuneRequestDTO dto = new ModificaComuneRequestDTO();
		dto.setId(1L);
		dto.setCap("8002");
		dto.setSiglaProvincia("blAb");
		dto.setNome("boh");
		
		HttpEntity<	ModificaComuneRequestDTO>entity = new HttpEntity<ModificaComuneRequestDTO>(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificacomune",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
		
	}
	@Test
	void modificaComuneNotAuth() {
		log.info("================siamo nel test modificaComuneNotAuth==================");
		ModificaComuneRequestDTO dto = new ModificaComuneRequestDTO();
		dto.setId(2L);
		dto.setCap("8002");
		dto.setSiglaProvincia("NA");
		dto.setNome("boh");
		
		HttpEntity<	ModificaComuneRequestDTO>entity = new HttpEntity<ModificaComuneRequestDTO>(dto);
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificacomune",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
	}
	@Test
	void modificaComuneNotFoundProvincia() {
		log.info("================siamo nel test modificaComuneNotFoundProvincia==================");
		ModificaComuneRequestDTO dto = new ModificaComuneRequestDTO();
		dto.setId(1L);
		dto.setCap("8002");
		dto.setSiglaProvincia("bb");
		dto.setNome("boh");
		
		HttpEntity<	ModificaComuneRequestDTO>entity = new HttpEntity<ModificaComuneRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificacomune",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
		
	}
	@Test
	void modificaComuneNotFoundComune() {
		log.info("================siamo nel test modificaComuneNotFoundComune==================");
		ModificaComuneRequestDTO dto = new ModificaComuneRequestDTO();
		dto.setId(3333333333L);
		dto.setCap("8002");
		dto.setSiglaProvincia("NA");
		dto.setNome("boh");
		
		HttpEntity<	ModificaComuneRequestDTO>entity = new HttpEntity<ModificaComuneRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificacomune",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
		
	}
	@Test
	void eliminaComune() {
		log.info("================siamo nel test eliminaComune==================");
		EliminaComuneRequestDTO dto = new EliminaComuneRequestDTO();
		dto.setId(1l);
		HttpEntity<	EliminaComuneRequestDTO >entity = new HttpEntity<EliminaComuneRequestDTO >(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminacomune",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void eliminaComuneKo() {
		log.info("================siamo nel test eliminaComuneKo==================");
		EliminaComuneRequestDTO dto = new EliminaComuneRequestDTO();
		dto.setId(1l);
		HttpEntity<	EliminaComuneRequestDTO >entity = new HttpEntity<EliminaComuneRequestDTO >(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminacomune",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void eliminaComuneNotAuth() {
		log.info("================siamo nel test eliminaComuneNotAuth==================");
		EliminaComuneRequestDTO dto = new EliminaComuneRequestDTO();
		dto.setId(1l);
		HttpEntity<	EliminaComuneRequestDTO >entity = new HttpEntity<EliminaComuneRequestDTO >(dto);
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminacomune",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void eliminaComuneNotFound() {
		log.info("================siamo nel test eliminaComuneNotFound==================");
		EliminaComuneRequestDTO dto = new EliminaComuneRequestDTO();
		dto.setId(2233333l);
		HttpEntity<	EliminaComuneRequestDTO >entity = new HttpEntity<EliminaComuneRequestDTO >(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminacomune",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void getAllComuneNome() {
		log.info("================siamo nel test getAllComuneNome==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticomuninome/San_Costanzo", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void getAllComuneNomeKo() {
		log.info("================siamo nel test getAllComuneNomeKo==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticomuninome/San_Costanzo", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllComuneNomeNotAuth() {
		log.info("================siamo nel test getAllComuneNomeNotAuth==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticomuninome/San_Costanzo", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllComuneNomeNotFound() {
		log.info("================siamo nel test getAllComuneNomeNotFound==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticomuninome/", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}

}
