package it.epicode.azienda.sedelegaletest;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.azienda.BasicTests;
import it.epicode.azienda.dto.EliminaProvinciaRequestDTO;
import it.epicode.azienda.dto.EliminaSedeLegaleRequestDTO;
import it.epicode.azienda.dto.InserisciSedeLegaleRequestDTO;
import it.epicode.azienda.dto.ModificaProvinciaRequestDTO;
import it.epicode.azienda.dto.ModificaSedeLegaleRequestDTO;
import lombok.extern.slf4j.Slf4j;
@Slf4j
public class SedeLegaleControllerTest extends BasicTests{

	@Override
	protected String getEntryPoint() {

		return "/sedelegale";
	}


	@Test
	void getAllSedeLegali() {
		log.info("================siamo nel test getAllSedeLegali==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tuttesedilegali", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);}

	@Test
	void getAllSedeLegaliKo() {
		log.info("================siamo nel test getAllSedeLegaliKo==================");
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tuttesedilegali", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllSedeLegaliNotAuth() {
		log.info("================siamo nel test getAllSedeLegaliNotAuth==================");
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tuttesedilegali", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}

	@Test
	void getAllSedeLegaliVia() {
		log.info("================siamo nel test getAllSedeLegaliVia==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tuttesedilegalivia/Via Milano", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void getAllSedeLegaliViaKo() {
		log.info("================siamo nel test getAllSedeLegaliViaKo==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tuttesedilegalivia/Via Milano", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllSedeLegaleNomeNotFound() {
		log.info("================siamo nel test getAllSedeLegaleNomeNotFound==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tuttesedilegalivia/", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void getAllSedeLegaleNomeNotAuth() {
		log.info("================siamo nel test getAllSedeLegaleNomeNotAuth==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tuttesedilegalivia/Via Milano", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void inserisciSedeLegale() {
		log.info("================siamo nel test inserisciSedeLegale==================");
		InserisciSedeLegaleRequestDTO dto =new InserisciSedeLegaleRequestDTO();
		dto.setVia("via fico");
		dto.setCap("9021");
		dto.setLocalita("Bolzano");
		dto.setIdComune(2l);
		HttpEntity<InserisciSedeLegaleRequestDTO>entity = new HttpEntity<InserisciSedeLegaleRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r= restTemplate.exchange(api()+"/inseriscisedelegale",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void inserisciSedeLegaleKo() {
		log.info("================siamo nel test inserisciSedeLegaleKo==================");
		InserisciSedeLegaleRequestDTO dto =new InserisciSedeLegaleRequestDTO();
		dto.setVia("via fico");
		dto.setCap("9021");
		dto.setLocalita("Bolzano");
		dto.setIdComune(1l);
		HttpEntity<InserisciSedeLegaleRequestDTO>entity = new HttpEntity<InserisciSedeLegaleRequestDTO>(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r= restTemplate.exchange(api()+"/inseriscisedelegale",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void inserisciSedeLegaleNotAuth() {
		log.info("================siamo nel test inserisciSedeLegaleNotAuth==================");
		InserisciSedeLegaleRequestDTO dto =new InserisciSedeLegaleRequestDTO();
		dto.setVia("via fico");
		dto.setCap("9021");
		dto.setLocalita("Bolzano");
		dto.setIdComune(1l);
		HttpEntity<InserisciSedeLegaleRequestDTO>entity = new HttpEntity<InserisciSedeLegaleRequestDTO>(dto);
		ResponseEntity<?>r= restTemplate.exchange(api()+"/inseriscisedelegale",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}@Test
	void inserisciSedeLegaleNotFound() {
		log.info("================siamo nel test inserisciSedeLegaleNotFound==================");
		InserisciSedeLegaleRequestDTO dto =new InserisciSedeLegaleRequestDTO();
		dto.setVia("via fico");
		dto.setCap("9021");
		dto.setLocalita("Bolzano");
		dto.setIdComune(3333333333333l);
		HttpEntity<InserisciSedeLegaleRequestDTO>entity = new HttpEntity<InserisciSedeLegaleRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r= restTemplate.exchange(api()+"/inseriscisedelegale",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void modificaSedeLegale() {
		log.info("================siamo nel test modificaSedeLegale==================");
		ModificaSedeLegaleRequestDTO dto =  new ModificaSedeLegaleRequestDTO();
		dto.setId(1L);
		dto.setCap("90021");
		dto.setLocalita("romania");
		dto.setVia("casa");
		dto.setIdComune(1l);

		HttpEntity<ModificaSedeLegaleRequestDTO >entity = new HttpEntity<ModificaSedeLegaleRequestDTO >(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificasedelegale",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void modificaSedeLegaleKo() {
		log.info("================siamo nel test modificaSedeLegaleKo==================");
		ModificaSedeLegaleRequestDTO dto =  new ModificaSedeLegaleRequestDTO();
		dto.setId(1L);
		dto.setCap("90021");
		dto.setLocalita("romania");
		dto.setVia("casa");
		dto.setIdComune(1l);

		HttpEntity<ModificaSedeLegaleRequestDTO >entity = new HttpEntity<ModificaSedeLegaleRequestDTO >(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificasedelegale",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void modificaSedeLegaleNotAuth() {
		log.info("================siamo nel test modificaSedeLegaleNotAuth==================");
		ModificaSedeLegaleRequestDTO dto =  new ModificaSedeLegaleRequestDTO();
		dto.setId(1L);
		dto.setCap("90021");
		dto.setLocalita("romania");
		dto.setVia("casa");
		dto.setIdComune(1l);

		HttpEntity<ModificaSedeLegaleRequestDTO >entity = new HttpEntity<ModificaSedeLegaleRequestDTO >(dto);
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificasedelegale",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void modificaSedeLegaleNotFoundSedeLegale() {
		log.info("================siamo nel test modificaSedeLegaleNotFoundSedeLegale==================");
		ModificaSedeLegaleRequestDTO dto =  new ModificaSedeLegaleRequestDTO();
		dto.setId(323L);
		dto.setCap("90021");
		dto.setLocalita("romania");
		dto.setVia("casa");
		dto.setIdComune(1l);

		HttpEntity<ModificaSedeLegaleRequestDTO >entity = new HttpEntity<ModificaSedeLegaleRequestDTO >(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificasedelegale",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void modificaSedeLegaleNotFoundComune() {
		log.info("================siamo nel test modificaSedeLegaleNotFoundComune==================");
		ModificaSedeLegaleRequestDTO dto =  new ModificaSedeLegaleRequestDTO();
		dto.setId(1L);
		dto.setCap("90021");
		dto.setLocalita("romania");
		dto.setVia("casa");
		dto.setIdComune(233232l);

		HttpEntity<ModificaSedeLegaleRequestDTO >entity = new HttpEntity<ModificaSedeLegaleRequestDTO >(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modificasedelegale",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void eliminaSedeLegale() {
		log.info("================siamo nel test eliminaSedeLegale==================");
		EliminaSedeLegaleRequestDTO dto = new EliminaSedeLegaleRequestDTO();
		dto.setId(1L);
		HttpEntity<EliminaSedeLegaleRequestDTO>entity = new HttpEntity<EliminaSedeLegaleRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminasedelegale",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void eliminaSedeLegaleKo() {
		log.info("================siamo nel test eliminaSedeLegaleKo==================");
		EliminaSedeLegaleRequestDTO dto = new EliminaSedeLegaleRequestDTO();
		dto.setId(1L);
		HttpEntity<EliminaSedeLegaleRequestDTO>entity = new HttpEntity<EliminaSedeLegaleRequestDTO>(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminasedelegale",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void eliminaSedeLegaleNotAuth() {
		log.info("================siamo nel test eliminaSedeLegaleNotAuth==================");
		EliminaSedeLegaleRequestDTO dto = new EliminaSedeLegaleRequestDTO();
		dto.setId(1L);
		HttpEntity<EliminaSedeLegaleRequestDTO>entity = new HttpEntity<EliminaSedeLegaleRequestDTO>(dto);
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminasedelegale",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}	
	@Test
	void eliminaSedeLegaleNotFound() {
		log.info("================siamo nel test eliminaSedeLegaleNotFound==================");
		EliminaSedeLegaleRequestDTO dto = new EliminaSedeLegaleRequestDTO();
		dto.setId(23232323L);
		HttpEntity<EliminaSedeLegaleRequestDTO>entity = new HttpEntity<EliminaSedeLegaleRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminasedelegale",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}


}
