package it.epicode.azienda.provinciatest;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.azienda.BasicTests;
import it.epicode.azienda.dto.EliminaProvinciaRequestDTO;
import it.epicode.azienda.dto.InserisciProvinciaRequestDTO;
import it.epicode.azienda.dto.ModificaProvinciaRequestDTO;
import lombok.extern.slf4j.Slf4j;
@Slf4j
public class ProvinciaControllerTest extends BasicTests {

	@Override
	protected String getEntryPoint() {

		return "/provincia";
	}

	@Test
	void getAllProvince() {
		log.info("================siamo nel test getAllProvince==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutteprovince", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

	}
	@Test
	void getAllProvinceKo() {
		log.info("================siamo nel test getAllProvinceKo==================");
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutteprovince", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllProvinceNotAuth() {
		log.info("================siamo nel test getAllProvinceNotAuth==================");
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutteprovince", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllProvinceNome() {
		log.info("================siamo nel test getAllProvinceNome==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutteprovincenome/Na", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void getAllProvinceNomeKo() {
		log.info("================siamo nel test getAllProvinceNomeKo==================");
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutteprovincenome/Na", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllProvinceNomeNotFound() {
		log.info("================siamo nel test getAllProvinceNomeNotFound==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutteprovincenome/", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void getAllProvinceNomeNotAut() {
		log.info("================siamo nel test getAllProvinceNomeNotAut==================");
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutteprovincenome/Na", HttpMethod.GET, HttpEntity.EMPTY,String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}

	@Test
	void inserisciProvincia() {
		log.info("================siamo nel test inserisciProvincia==================");
		InserisciProvinciaRequestDTO dto = new InserisciProvinciaRequestDTO();
		dto.setSigla("URS");
		dto.setRegione("Putin");
		dto.setProvincia("rassian");
		HttpEntity<InserisciProvinciaRequestDTO>entity = new HttpEntity<InserisciProvinciaRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/inserisciprovincia",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

	}
	@Test
	void inserisciProvinciaKo() {
		log.info("================siamo nel test inserisciProvinciaKo==================");
		InserisciProvinciaRequestDTO dto = new InserisciProvinciaRequestDTO();
		dto.setSigla("URS");
		dto.setRegione("Putin");
		dto.setProvincia("rassian");
		HttpEntity<InserisciProvinciaRequestDTO>entity = new HttpEntity<InserisciProvinciaRequestDTO>(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r1 = restTemplate.exchange(api()+ "/inserisciprovincia",HttpMethod.POST,entity,String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);

	}
	@Test
	void inserisciProvinciaNotAuth() {
		log.info("================siamo nel test inserisciProvinciaNotAuth==================");
		InserisciProvinciaRequestDTO dto = new InserisciProvinciaRequestDTO();
		dto.setSigla("URS");
		dto.setRegione("Putin");
		dto.setProvincia("rassian");
		HttpEntity<InserisciProvinciaRequestDTO>entity = new HttpEntity<InserisciProvinciaRequestDTO>(dto);
		ResponseEntity<?>r2 = restTemplate.exchange(api()+ "/inserisciprovincia",HttpMethod.POST,entity,String.class);
		assertThat(r2.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

	}
	@Test
	void modificaProvinciaNotFound() {
		log.info("================siamo nel test modificaProvinciaNotFound==================");
		ModificaProvinciaRequestDTO dto =  new ModificaProvinciaRequestDTO();
		dto.setSigla("URS");
		dto.setProvincia("boh");
		dto.setRegione("boh2");
		HttpEntity<ModificaProvinciaRequestDTO>entity = new HttpEntity<ModificaProvinciaRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modficaprovincia",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void modificaProvincia() {
		log.info("================siamo nel test modificaProvincia==================");
		ModificaProvinciaRequestDTO dto =  new ModificaProvinciaRequestDTO();
		dto.setSigla("Na");
		dto.setProvincia("boh");
		dto.setRegione("boh2");
		HttpEntity<ModificaProvinciaRequestDTO>entity = new HttpEntity<ModificaProvinciaRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/modficaprovincia",HttpMethod.PUT,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}





	@Test
	void eliminaProvincia() {
		log.info("================siamo nel test eliminaProvincia==================");
		EliminaProvinciaRequestDTO dto = new EliminaProvinciaRequestDTO();
		dto.setSigla("URS");
		HttpEntity<EliminaProvinciaRequestDTO>entity = new HttpEntity<EliminaProvinciaRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminaprovincia",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

	}
	@Test
	void eliminaProvinciaKo() {
		log.info("================siamo nel test eliminaProvinciaKo==================");
		EliminaProvinciaRequestDTO dto = new EliminaProvinciaRequestDTO();
		dto.setSigla("URS");
		HttpEntity<EliminaProvinciaRequestDTO>entity = new HttpEntity<EliminaProvinciaRequestDTO>(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r1 = restTemplate.exchange(api()+ "/eliminaprovincia",HttpMethod.DELETE,entity,String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);

	}
	void eliminaProvinciaNotAuth() {
		log.info("================siamo nel test eliminaProvinciaNotAuth==================");
		EliminaProvinciaRequestDTO dto = new EliminaProvinciaRequestDTO();
		dto.setSigla("URS");
		HttpEntity<EliminaProvinciaRequestDTO>entity = new HttpEntity<EliminaProvinciaRequestDTO>(dto);
		ResponseEntity<?>r2 = restTemplate.exchange(api()+ "/eliminaprovincia",HttpMethod.DELETE,entity,String.class);
		assertThat(r2.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

	}
	void eliminaProvinciaNotFound() {
		log.info("================siamo nel test eliminaProvinciaNotFound==================");
		EliminaProvinciaRequestDTO dto = new EliminaProvinciaRequestDTO();
		dto.setSigla("URS2");
		HttpEntity<EliminaProvinciaRequestDTO>entity = new HttpEntity<EliminaProvinciaRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r3 = restTemplate.exchange(api()+ "/eliminaprovincia",HttpMethod.DELETE,entity,String.class);
		assertThat(r3.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);


	}










}
