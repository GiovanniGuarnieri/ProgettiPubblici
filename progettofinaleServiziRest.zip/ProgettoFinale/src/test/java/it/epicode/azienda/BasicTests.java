package it.epicode.azienda;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;

import it.epicode.azienda.impl.LoginRequest;
import lombok.extern.slf4j.Slf4j;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Slf4j
public abstract class BasicTests {
	@LocalServerPort
	protected int port;
	@Autowired
	protected TestRestTemplate restTemplate;
	
	

	
	protected String getAdminToken () {
		LoginRequest loginRequest = new LoginRequest();
		loginRequest.setUserName("giovanni");
		loginRequest.setPassword("maurito");
		HttpEntity<LoginRequest> login = new HttpEntity<LoginRequest>(loginRequest);
		String jwt = restTemplate.postForObject("http://localhost:" + port + "/api/auth/login/jwt", loginRequest, String.class);
		log.info(jwt);
		return jwt;
	}
	protected String getUserToken () {
		LoginRequest loginRequest = new LoginRequest();
		loginRequest.setUserName("mauro");
		loginRequest.setPassword("mauro");
		HttpEntity<LoginRequest> login = new HttpEntity<LoginRequest>(loginRequest);
		String jwt = restTemplate.postForObject("http://localhost:" + port + "/api/auth/login/jwt", loginRequest, String.class);
		log.info(jwt);
		return jwt;
	}
	protected String getToken () {
		LoginRequest loginRequest = new LoginRequest();
		loginRequest.setUserName("");
		loginRequest.setPassword("");
		HttpEntity<LoginRequest> login = new HttpEntity<LoginRequest>(loginRequest);
		String jwt = restTemplate.postForObject("http://localhost:" + port + "/api/auth/login/jwt", loginRequest, String.class);
		log.info(jwt);
		return jwt;
	}
	
	protected HttpEntity getUnauthorizedEntity() {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization" , "");
		HttpEntity<String> jwtEntity = new HttpEntity<String>(headers);
		return jwtEntity;
	}
	
	protected HttpEntity getAuthorizedEntity() {
		HttpEntity<String> jwtEntity = new HttpEntity<String>(getAuthorizedHeaders());
		return jwtEntity;
	}
	
	protected HttpHeaders getAuthorizedHeaders() {
		String jwt = getAdminToken();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + jwt);
		return headers;
	}
	protected HttpHeaders getUnauthorizedRoleHeaders() {
		String jwt = getUserToken();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization" , "Bearer " + jwt);
		return headers;
	}
	

	
	protected abstract String getEntryPoint();
	protected String api() {
		return  "http://localhost:" + port  + getEntryPoint();
	}
	
}
	
