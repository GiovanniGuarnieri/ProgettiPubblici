package it.epicode.azienda.clientetest;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.azienda.BasicTests;
import it.epicode.azienda.dto.CercaPerDataResponseDTO;
import it.epicode.azienda.dto.EliminaClienteRequestDTO;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class ClienteControllerTest extends BasicTests {
	
	

	@Override
	protected String getEntryPoint() {
	
		return "/cliente";
	}
	
	
	
	@Test
	void getAllClienti() {
		log.info("================siamo nel test getAllClienti==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticlienti", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void getAllClientiKo() {
		log.info("================siamo nel test getAllClientiKo==================");
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutticlienti", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllClientiNotAuth() {
		log.info("================siamo nel test getAllClientiNotAuth==================");
		ResponseEntity<String> r1 = restTemplate.exchange(api() + "/tutticlienti", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r1.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllClienteProvinciaSedelegale() {
		log.info("================siamo nel test getAllClienteProvinciaSedelegale==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/cercaprovinciasedelegale/Bari", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void getAllClienteProvinciaSedelegaleKo() {
		log.info("================siamo nel test getAllClienteProvinciaSedelegaleKo==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/cercaprovinciasedelegale/Bari", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllClienteProvinciaSedelegaleNotAuth() {
		log.info("================siamo nel test getAllClienteProvinciaSedelegaleNotAuth==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/cercaprovinciasedelegale/Bari", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllClienteProvinciaSedelegaleNotFound() {
		log.info("================siamo nel test getAllClienteProvinciaSedelegaleNotFound==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/cercaprovinciasedelegale/", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void getAllClienteDataUltimoContatto() {
		log.info("================siamo nel test getAllClienteDataUltimoContatto==================");
		 CercaPerDataResponseDTO dto = new  CercaPerDataResponseDTO();
		dto.setData(LocalDate.parse("2002-02-20"));
		HttpEntity<	CercaPerDataResponseDTO>entity = new HttpEntity<CercaPerDataResponseDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/tutticlientidataultimocontatto",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	void getAllClienteDataUltimoContattoKo() {
		log.info("================siamo nel test getAllClienteDataUltimoContattoKo==================");
		 CercaPerDataResponseDTO dto = new  CercaPerDataResponseDTO();
		dto.setData(LocalDate.parse("2002-02-20"));
		HttpEntity<	CercaPerDataResponseDTO>entity = new HttpEntity<CercaPerDataResponseDTO>(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/tutticlientidataultimocontatto",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	void getAllClienteDataUltimoContattoNoAuth() {
		log.info("================siamo nel test getAllClienteDataUltimoContattoNoAuth==================");
		 CercaPerDataResponseDTO dto = new  CercaPerDataResponseDTO();
		dto.setData(LocalDate.parse("2002-02-20"));
		HttpEntity<	CercaPerDataResponseDTO>entity = new HttpEntity<CercaPerDataResponseDTO>(dto);
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/tutticlientidataultimocontatto",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllClienteDataInserimento() {
		log.info("================siamo nel test getAllClienteDataInserimento==================");
		 CercaPerDataResponseDTO dto = new  CercaPerDataResponseDTO();
		dto.setData(LocalDate.parse("2002-02-20"));
		HttpEntity<	CercaPerDataResponseDTO>entity = new HttpEntity<CercaPerDataResponseDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/tutticlientidatainserimento",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void getAllClienteDataDataInserimentoKo() {
		log.info("================siamo nel test getAllClienteDataDataInserimentoKo==================");
		 CercaPerDataResponseDTO dto = new  CercaPerDataResponseDTO();
		dto.setData(LocalDate.parse("2002-02-20"));
		HttpEntity<	CercaPerDataResponseDTO>entity = new HttpEntity<CercaPerDataResponseDTO>(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/tutticlientidatainserimento",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void getAllClienteDataUltimoContattoNotAuth() {
		log.info("================siamo nel test getAllClienteDataUltimoContattoNotAuth==================");
		 CercaPerDataResponseDTO dto = new  CercaPerDataResponseDTO();
		dto.setData(LocalDate.parse("2002-02-20"));
		HttpEntity<	CercaPerDataResponseDTO>entity = new HttpEntity<CercaPerDataResponseDTO>(dto);
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/tutticlientidatainserimento",HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllClienteFatturatoAnnuale() {
		log.info("================siamo nel test getAllClienteFatturatoAnnuale==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticlientifatturatoannuale/20000", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void getAllClienteFatturatoAnnualeKo() {
		log.info("================siamo nel test getAllClienteFatturatoAnnualeKo==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticlientifatturatoannuale/20000", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAllClienteFatturatoAnnualeNotFound() {
		log.info("================siamo nel test getAllClienteFatturatoAnnualeNotFound==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticlientifatturatoannuale/", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void getAllClienteFatturatoAnnualeNotAuth() {
		log.info("================siamo nel test getAllClienteFatturatoAnnualeNotAuth==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticlientifatturatoannuale/20000", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAlltuttiClientiNome() {
		log.info("================siamo nel test getAlltuttiClientiNome==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticlientinome/luca", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void getAlltuttiClientiNomeKo() {
		log.info("================siamo nel test getAlltuttiClientiNomeKo==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticlientinome/luca", HttpMethod.GET,getUnauthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAlltuttiClientiNomeNoAuth() {
		log.info("================siamo nel test getAlltuttiClientiNomeNoAuth==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticlientinome/luca", HttpMethod.GET,HttpEntity.EMPTY,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void getAlltuttiClientiNomeNotFound() {
		log.info("================siamo nel test getAlltuttiClientiNomeNotFound==================");
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tutticlientinome/", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	@Test
	void eliminaClienti() {
		log.info("================siamo nel test eliminaClienti==================");
		EliminaClienteRequestDTO dto = new EliminaClienteRequestDTO();
		dto.setId(1l);
		HttpEntity<	EliminaClienteRequestDTO >entity = new HttpEntity<EliminaClienteRequestDTO >(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminacliente",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void eliminaClientiKo() {
		log.info("================siamo nel test eliminaClientiKo==================");
		EliminaClienteRequestDTO dto = new EliminaClienteRequestDTO();
		dto.setId(1l);
		HttpEntity<	EliminaClienteRequestDTO >entity = new HttpEntity<EliminaClienteRequestDTO >(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminacliente",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void eliminaClientiNotAuth() {
		log.info("================siamo nel test eliminaClientiNotAuth==================");
		EliminaClienteRequestDTO dto = new EliminaClienteRequestDTO();
		dto.setId(1l);
		HttpEntity<	EliminaClienteRequestDTO >entity = new HttpEntity<EliminaClienteRequestDTO >(dto);
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminacliente",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	@Test
	void eliminaClientiNotFound() {
		log.info("================siamo nel test eliminaClientiNotFound==================");
		EliminaClienteRequestDTO dto = new EliminaClienteRequestDTO();
		dto.setId(14l);
		HttpEntity<	EliminaClienteRequestDTO >entity = new HttpEntity<EliminaClienteRequestDTO >(dto,getAuthorizedHeaders());
		ResponseEntity<?>r = restTemplate.exchange(api()+ "/eliminacliente",HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	


}
