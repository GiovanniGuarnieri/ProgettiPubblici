package it.epicode.azienda.services;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Service;

import it.epicode.azienda.dto.CercaPerDataResponseDTO;
import it.epicode.azienda.dto.EliminaClienteRequestDTO;
import it.epicode.azienda.dto.InserisciClienteRequestDTO;
import it.epicode.azienda.dto.ModificaClienteRequestDTO;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.model.Cliente;
import it.epicode.azienda.model.SedeLegale;
import it.epicode.azienda.model.SedeOperativa;
import it.epicode.azienda.repository.ClienteRepository;
import it.epicode.azienda.repository.SedeLegaleRepository;
import it.epicode.azienda.repository.SedeOperativaRepository;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class ClienteService {
	@Autowired
	ClienteRepository cr;
	@Autowired
	SedeLegaleRepository slr;
	@Autowired
	SedeOperativaRepository sor;

	/**
	 * metodo che inserisce nel db un cliente con associazione della sede legale,sede operativa con request mapping POST
	 * @param dto
	 * @throws NotFoundException
	 */
	public void inserisciCliente(InserisciClienteRequestDTO dto) throws NotFoundException {
		log.info("===========================siamo nel service inserisci cliente==================================================");
		log.info("cognome "+ dto.getCognomeContatto());
		log.info("nome contatto" + dto.getNomeContatto());
		log.info("email "+ dto.getEmail());
		log.info("email contatto "+dto.getEmailContatto());
		log.info("partia iva "+dto.getPartitaIva());
		log.info("pec " + dto.getPec());
		log.info("ragione sociale " + dto.getRagioneSociale());
		log.info("telefono "+ dto.getTelefono());
		log.info("telefono contatto " + dto.getTelefonoContatto());
		log.info("data inserimento" + dto.getDataInserimento().toString());
		log.info("data ultimo contatto" + dto.getDataUltimoContatto().toString());
		log.info("tipo cliente"+ dto.getTipoCliente().toString());
		Cliente cl = new Cliente();
		BeanUtils.copyProperties(dto, cl);
		if(slr.existsById(dto.getIdSedeLegale())) {
			log.info("id sede legale "+dto.getIdSedeLegale().toString());
			SedeLegale sedeLegale = slr.findById(dto.getIdSedeLegale()).get();
			sedeLegale.setCliente(cl);
			cl.setSedeLegale(sedeLegale);

		}else {
			throw new  NotFoundException("sede legale non trovata");
		}

		if(sor.existsById(dto.getIdSedeOperativa())) {
			log.info("id sede operativa "+dto.getIdSedeOperativa().toString());
			SedeOperativa sedeOperativa = sor.findById(dto.getIdSedeOperativa()).get();
			sedeOperativa.setCliente(cl);
			cl.setSedeOperativa(sedeOperativa);

		}
		else {
			throw new NotFoundException("sede operativa non trovata");
		}

		cr.save(cl);
	}

	/**
	 * modifica un cliente con associazione della sede legale,sede operativa con request mapping PUT
	 * @param dto
	 * @throws NotFoundException
	 */
	public void	modificaCliente(ModificaClienteRequestDTO dto) throws NotFoundException {
		log.info("===========================siamo nel service modifica cliente==================================================");
		if(cr.existsById(dto.getId())) {
			log.info("id cliente" + dto.getId().toString() );
			log.info("cognome "+ dto.getCognomeContatto());
			log.info("nome contatto" + dto.getNomeContatto());
			log.info("email "+ dto.getEmail());
			log.info("email contatto "+dto.getEmailContatto());
			log.info("partia iva "+dto.getPartitaIva());
			log.info("pec " + dto.getPec());
			log.info("ragione sociale " + dto.getRagioneSociale());
			log.info("telefono "+ dto.getTelefono());
			log.info("telefono contatto " + dto.getTelefonoContatto());
			log.info("data inserimento" + dto.getDataInserimento().toString());
			log.info("data ultimo contatto" + dto.getDataUltimoContatto().toString());
			log.info("tipo cliente "+ dto.getTipoCliente().toString());
			Cliente cl = cr.findById(dto.getId()).get();
			BeanUtils.copyProperties(dto, cl);
			if(slr.existsById(dto.getIdSedeLegale())) {
				log.info("id sede legale "+dto.getIdSedeLegale().toString());
				SedeLegale sedeLegale = slr.findById(dto.getIdSedeLegale()).get();
				sedeLegale.setCliente(cl);
				cl.setSedeLegale(sedeLegale);

			}else {
				throw new  NotFoundException("sede legale non trovata");
			}

			if(sor.existsById(dto.getIdSedeOperativa())) {
				log.info("id sede operativa "+dto.getIdSedeOperativa().toString());
				SedeOperativa sedeOperativa = sor.findById(dto.getIdSedeOperativa()).get();
				sedeOperativa.setCliente(cl);
				cl.setSedeOperativa(sedeOperativa);

			}
			else {
				throw new NotFoundException("sede operativa non trovata");
			}

			cr.save(cl);
		}
	}
	/**
	 * elimina un cliente presente nel db attraverso la ricerda dell'id con request mapping DELETE
	 * @param dto
	 * @throws NotFoundException
	 */
	public void eliminaCliente(EliminaClienteRequestDTO dto) throws NotFoundException {
		log.info("===========================siamo nel service elimina cliente==================================================");
		if(cr.existsById(dto.getId())) {
			log.info("id cliente " + dto.getId().toString());
			Cliente c = cr.findById(dto.getId()).get();
			cr.delete(c);
		}
		else {
			throw new NotFoundException("cliente non trovato");
		}
	}

	/**
	 * ricerca tutti i clienti con possibilità di paginazione attraverso il request mapping GET
	 * @param page
	 * @return
	 */
	public Page cercaClienti(Pageable page) {
		log.info("===========================siamo nel service cerca cliente==================================================");
		return  cr.findAll(page);
	}

	/**
	 * ricerca clienti presenti nel db attraverso la ricerca del nome con possibilita di paginazione attraverso il request mapping GET
	 * @param nomeContatto
	 * @param page
	 * @return
	 */
	public Page cercaClientiNome(String nomeContatto,Pageable page) {
		log.info("===========================siamo nel service cerca cliente per nome==================================================");
		log.info("nome contatto "+ nomeContatto);
		return cr.findByNomeContattoContaining(nomeContatto, page);
	}

	/**
	 * ricerca i clienti presenti nel db attraverso la ricerca del fatturato annuale con possibilita di paginazione attraverso il request mapping GET
	 * @param fatturatoAnnuale
	 * @param page
	 * @return
	 */
	public Page cercaClientiFatturato(double fatturatoAnnuale,Pageable page) {
		log.info("===========================siamo nel service cerca cliente per fatturato annuale==================================================");
		log.info("importo fattura annuale "+ fatturatoAnnuale);
		return cr.findByFatturatoAnnuale(fatturatoAnnuale, page);
		
		

	}
	/**
	 * ricerca i clienti presenti nel db attraverso la ricerca della data inserimento usando un dto con possibilita di paginazione attraverso il request mapping POST
	 * @param dto
	 * @param page
	 * @return
	 */
	public Page cercaClientiDataInserimento(CercaPerDataResponseDTO dto,Pageable page) {
		log.info("===========================siamo nel service cerca cliente per cercaClientiDataInserimento==================================================");
		log.info("data inserita " + dto.getData().toString());
		return cr.findByDataInserimento(dto.getData(), page);
	}


	/**
	 * ricerca i clienti presenti nel db attraverso la ricerca della data ultimo contatto usando un dto con possibilita di paginazione attraverso il request mapping POST
	 * @param dto
	 * @param page
	 * @return
	 */
	public Page cercaClientiDataUltimoContatto(CercaPerDataResponseDTO dto,Pageable page) {
		log.info("===========================siamo nel service cerca cliente per cercaClientiDataUltimoContatto==================================================");
		log.info("data inserita "+ dto.getData().toString());
		return cr.findByDataUltimoContatto(dto.getData(), page);
		
	}

	/**
	 * ricerca i clienti presenti nel db attraverso la ricerca della provincia usando una query nel repository con possibilita di paginazione attraverso il request mapping GET
	 * @param provincia
	 * @param page
	 * @return
	 */
	public Page cercaClientePerProvincia(String provincia, Pageable page) {
		log.info("===========================siamo nel service cerca cliente per cercaClientePerProvincia==================================================");
		log.info("provincia " + provincia);
		return cr.findByProvinciaSedeLegale(provincia, page);
		
	}










}
