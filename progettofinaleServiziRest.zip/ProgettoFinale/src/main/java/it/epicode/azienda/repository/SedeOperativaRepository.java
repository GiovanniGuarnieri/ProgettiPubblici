package it.epicode.azienda.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.azienda.model.SedeOperativa;

public interface SedeOperativaRepository extends PagingAndSortingRepository<SedeOperativa, Long>{

	
	Page <SedeOperativa>findByViaContaining(Pageable page,String via);
}
