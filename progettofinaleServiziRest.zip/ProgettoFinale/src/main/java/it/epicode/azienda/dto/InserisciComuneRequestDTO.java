package it.epicode.azienda.dto;

import javax.validation.constraints.NotBlank;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InserisciComuneRequestDTO {
	@NotBlank(message = "il campo nome non deve essere vuoto")
	private String nome;
	@NotBlank(message = "il campo siglaProvincia non deve essere vuoto")
	private String siglaProvincia;
	@NotBlank(message = "il campo cap non deve essere vuoto")
	private String cap;
}
