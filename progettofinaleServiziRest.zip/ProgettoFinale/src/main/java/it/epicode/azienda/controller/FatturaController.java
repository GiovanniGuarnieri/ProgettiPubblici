package it.epicode.azienda.controller;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.azienda.dto.CambiaStatoFatturaRequestDTO;
import it.epicode.azienda.dto.CercaPerAnnoResponseDTO;
import it.epicode.azienda.dto.CercaPerDataResponseDTO;
import it.epicode.azienda.dto.EliminaFatturaRequestDTO;
import it.epicode.azienda.dto.InserisciFatturaRequestDTO;
import it.epicode.azienda.dto.ModificaFatturaRequestDTO;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.services.FatturaService;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
@RequestMapping("/fattura")
public class FatturaController {

	@Autowired
	FatturaService fatturaService;
	@Operation (summary = "Inserisce una fattura nel db", description = "inserisce una fattura nel db ")
	@ApiResponse(responseCode = "200" , description = "cliente inserito con successo nel db !")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inseriscifattura" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisciFattura(@Valid @RequestBody InserisciFatturaRequestDTO dto) throws NotFoundException {
		log.info("===========================================siamo nel controller inserisci fattura ===========================================");
		fatturaService.inserisciFattura(dto);
		return ResponseEntity.ok("FATTURA INSERITA");
	}

	@Operation (summary = "modifica una fattura presente nel db ", description = "modifica una fattura presente nel db ")
	@ApiResponse(responseCode = "200" , description = "modifica avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modificafattura")
	public ResponseEntity modificaFattura(@Valid @RequestBody ModificaFatturaRequestDTO dto) throws NotFoundException {
		log.info("===========================================siamo nel controller modifica fattura===========================================");
		fatturaService.modificaFattura(dto);
		return ResponseEntity.ok("FATTURA MODIFICATA");
	}
	@Operation (summary = "elimina una fattura presente nel db", description = "elimina una fattura presente nel db ")
	@ApiResponse(responseCode = "200" , description = "eliminazione avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/eliminafattura")
	public ResponseEntity eliminaFattura(@Valid @RequestBody EliminaFatturaRequestDTO dto ) throws NotFoundException {
		log.info("===========================================siamo nel controller elimina fattura ===========================================");
		fatturaService.eliminaFattura(dto);
		return ResponseEntity.ok("FATTURA ELIMINATA");
	}

	@Operation (summary = "ritorna tutte fatture  presenti nel db", description = "ritorna la lista di tutte le fatture presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista fattura")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tuttefatture")
	public ResponseEntity tutteLeFatture(Pageable page) {
		log.info("===========================================siamo nel controller cerca fatture ===========================================");
		return ResponseEntity.ok(fatturaService.cercaFattura(page));
	}

	@Operation (summary = "ritorna tutti i clienti a cui è associata almeno una fattura  presenti nel db", description = "ritorna la lista di clienti a cui è associata almeno una fattura presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista fattura")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tutticlientifattura")
	public ResponseEntity tuttiClientiFattura(Pageable page) {
		log.info("===========================================siamo nel controller tuttiClientiFattura ===========================================");
		return ResponseEntity.ok(fatturaService.cercaClienti(page));
	}
	@Operation (summary = "ritorna i clienti tramite la ricerca per id", description = "ritorna i clienti tramite la ricerca per id presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista fattura")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tutticlientiid/{id}")
	public ResponseEntity tuttiClientiNome(@PathVariable("id")Long id,Pageable page) {
		log.info("===========================================siamo nel controller tuttiClientiNome ===========================================");
		return ResponseEntity.ok(fatturaService.cercaClienteid(id,page));
	}
	@Operation (summary = "ritorna le fatture  tramite la ricerca per stato fattura", description = "ritorna le fatture  tramite la ricerca per stato fattura presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista fattura")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tuttefatturestatofattura/{statoFattura}")
	public ResponseEntity tuttiFaattureStatoFattura(@PathVariable("statoFattura")String statoFattura,Pageable page) {
		log.info("===========================================siamo nel controller tuttiFaattureStatoFattur ===========================================");
		return ResponseEntity.ok(fatturaService.cercaStatoFattura(statoFattura,page));
	}
	@Operation (summary = "ritorna le fatture  tramite la ricerca per data", description = "ritorna le fatture  tramite la ricerca per data fattura presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista clienti")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping ("/tuttefatturedata")
	public ResponseEntity tutteFatturePerData(@Valid @RequestBody CercaPerDataResponseDTO dto,Pageable page) {
		log.info("===========================================siamo nel controller tutteFatturePerData ===========================================");
		return ResponseEntity.ok(fatturaService.cercaPerData(dto,page));
	}
	@Operation (summary = "ritorna le fatture  tramite la ricerca per importo", description = "ritorna le fatture  tramite la ricerca per importo fattura presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista fatture")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tuttefattureperimporto/{importo}")
	public ResponseEntity tutteFatturePerImporto(@PathVariable("importo")BigDecimal importo,Pageable page) {
		log.info("===========================================siamo nel controller tutteFatturePerImporto ===========================================");
		return ResponseEntity.ok(fatturaService.cercaPerImporto(importo,page));
	}
	@Operation (summary = "ritorna le fatture  tramite la ricerca per range importo", description = "ritorna le fatture  tramite la ricerca per range importo fattura presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista fatture")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tuttefattureperRangeimporto/{importoMin}/{importoMax}")
	public ResponseEntity tutteFatturePerImporto(@PathVariable BigDecimal importoMin,BigDecimal importoMax,Pageable page) {
		log.info("===========================================siamo nel controller tutteFatturePerImporto ===========================================");
		return ResponseEntity.ok(fatturaService.cercaPerRangeImporto(importoMin, importoMax, page));
	}

	@Operation (summary = "ritorna le fatture  tramite la ricerca per anno ", description = "ritorna le fatture  tramite la ricerca per anno fattura presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista fatture")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tuttefattureanno/{anno}")
	public ResponseEntity tutteFatturePerAnno(@PathVariable String anno,Pageable page) {
		log.info("===========================================siamo nel controller tutteFatturePerAnno ===========================================");
		return ResponseEntity.ok(fatturaService.cercaPerAnno(anno,page));
	}

	@Operation (summary = "cambia lo stato della fattura", description = "cambia lo stato della fattura ")
	@ApiResponse(responseCode = "200" , description = "stato fattura modificato")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping ("/cambiastatofattura")
	public ResponseEntity modificaStatoFattura(@Valid @RequestBody CambiaStatoFatturaRequestDTO dto) throws NotFoundException {
		log.info("===========================================siamo nel controller modificaStatoFattura ===========================================");
		fatturaService.cambiaStatoFattura(dto);
		return ResponseEntity.ok("stato fattura modificato");}


}
