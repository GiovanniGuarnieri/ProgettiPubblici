package it.epicode.azienda.repository;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.azienda.model.Fattura;

public interface FatturaRepository extends PagingAndSortingRepository<Fattura, Long>{
	
	@Query("select f from Fattura f join f.cliente c ")
	Page<Fattura>findAllByCliente(Pageable page);
	
	@Query("select f from Fattura f join f.cliente c where c.id=?1")
	Page<Fattura>findByClienteId(Long id,Pageable page);
	
	Page<Fattura>findByStatoFattura( String statoFattura,Pageable page);
	
	Page<Fattura>findByData(LocalDate data,Pageable page);
	
	@Query("select f from Fattura f where f.data between ?1 and ?2")
	Page<Fattura>findByAnno(LocalDate dataStart,LocalDate dataTo,Pageable page);
	
	Page<Fattura>findByImporto(BigDecimal importo,Pageable page);
	
	Page<Fattura>findByAnno(Integer anno,Pageable page);
	

	//@Query(value = "select * from Fattura where importo between ?1 and ?2",nativeQuery = true)
	@Query("select f from Fattura f where f.importo between ?1 and ?2")
	Page<Fattura>findAllByImporto(BigDecimal importoMin, BigDecimal importoMax,Pageable page);
	

	

}
