package it.epicode.azienda.dto;

import javax.validation.constraints.NotBlank;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ModificaProvinciaRequestDTO {
	@NotBlank(message = "il campo sigla non deve essere vuoto")
	private String sigla;
	@NotBlank(message = "il campo provincia non deve essere vuoto")
	private String provincia;
	@NotBlank(message = "il campo regione non deve essere vuoto")
	private String regione;


}
