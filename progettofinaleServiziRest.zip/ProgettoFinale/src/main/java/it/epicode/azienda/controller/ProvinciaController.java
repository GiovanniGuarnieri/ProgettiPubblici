package it.epicode.azienda.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.azienda.dto.EliminaProvinciaRequestDTO;
import it.epicode.azienda.dto.InserisciProvinciaRequestDTO;
import it.epicode.azienda.dto.ModificaProvinciaRequestDTO;
import it.epicode.azienda.errors.ElementAlreadyPresentException;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.services.ProvinciaService;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
@RequestMapping("/provincia")
public class ProvinciaController {

	@Autowired
	ProvinciaService provinciaService;
	@Operation (summary = "Inserisce una provincia nel db", description = "inserisce una provincia nel db ")
	@ApiResponse(responseCode = "200" , description = "provincia inserita con successo nel db !")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inserisciprovincia" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisciProvincia(@Valid @RequestBody InserisciProvinciaRequestDTO dto) throws  ElementAlreadyPresentException {
		log.info("===========================================siamo nel controller  inserisciProvincia ===========================================");
		provinciaService.inserisciProvincia(dto);
		return ResponseEntity.ok("PROVINCIA INSERITA");
	}
	@Operation (summary = "elimina una provincia presente nel db", description = "elimina una provincia presente nel db ")
	@ApiResponse(responseCode = "200" , description = "eliminazione avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/eliminaprovincia")
	public ResponseEntity eliminaProvincia(@Valid @RequestBody EliminaProvinciaRequestDTO dto ) throws NotFoundException {
		log.info("===========================================siamo nel controller   eliminaProvincia ===========================================");
		provinciaService.eliminaProvincia(dto);
		return ResponseEntity.ok("PROVINCIA ELIMINATA");
	}
	@Operation (summary = "ritorna tutte le province   presenti nel db", description = "ritorna la lista di tutte le province presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista clienti")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tutteprovince")
	public ResponseEntity tutteProvince(Pageable page) {
		log.info("===========================================siamo nel controller   tutteProvince ===========================================");
		return ResponseEntity.ok(provinciaService.cercaProvincia(page));
	}
	@Operation (summary = "modifica una provincia presente nel db ", description = "modifica una provincia presente nel db ")
	@ApiResponse(responseCode = "200" , description = "modifica avvenuta")
	@ApiResponse(responseCode ="401,403" , description = "Not Authenticated or you may have not role for this! ")
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modificaprovincia")
	public ResponseEntity modificaprovincia(@Valid @RequestBody ModificaProvinciaRequestDTO dto) throws NotFoundException {
		log.info("===========================================siamo nel controller   modificaprovincia ===========================================");
		provinciaService.modificaProvincia(dto);
		return ResponseEntity.ok("PROVINCIA MODIFICATA");
	}
	@Operation (summary = "ritorna tutte le province per nome della provincia  presenti nel db", description = "ritorna tutte le province per nome della provincia  presenti nel db ")
	@ApiResponse(responseCode = "200" , description = "lista clienti")
	@ApiResponse(responseCode ="401" , description = "Not Authenticated")
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tutteprovincenome/{provincia}")
	public ResponseEntity tutteProvincieNome(@PathVariable("provincia")String provincia,Pageable page) {
		log.info("===========================================siamo nel controller  tutteProvincieNome ===========================================");
		return ResponseEntity.ok(provinciaService.cercaProvinciaNome(page,provincia));
	}


}
