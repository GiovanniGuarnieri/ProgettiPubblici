package it.epicode.azienda.importazionecsv;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ProvinciaDtoCsv {

	private String sigla;
	@JsonProperty("Provincia")
	private String provincia;
	@JsonProperty("Regione")
	private String regione;
	

}
