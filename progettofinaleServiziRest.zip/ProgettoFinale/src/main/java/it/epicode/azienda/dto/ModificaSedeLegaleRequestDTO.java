package it.epicode.azienda.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ModificaSedeLegaleRequestDTO {
	@NotNull(message = "il campo id non deve essere vuoto")
	 private Long id;
	@NotBlank(message = "il campo via non deve essere vuoto")
	 private String via;
	@NotBlank(message = "il campo localita non deve essere vuoto")
	 private String localita;
	@NotBlank(message = "il campo cap non deve essere vuoto")
	 private String cap;
	@NotNull(message = "il campo id comune non deve essere vuoto")
	 private Long idComune;
}
