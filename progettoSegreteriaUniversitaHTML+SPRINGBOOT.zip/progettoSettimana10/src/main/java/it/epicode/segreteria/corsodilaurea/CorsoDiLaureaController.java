package it.epicode.segreteria.corsodilaurea;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.servlet.ModelAndView;

import it.epicode.segreteria.services.SegreteriaService;
import it.epicode.segreteria.studente.Studente;
import lombok.extern.slf4j.Slf4j;
@Controller
@Slf4j
public class CorsoDiLaureaController {
	
	@Autowired
	SegreteriaService ss;
	
	@GetMapping("/form-inseriscicorso")
	public ModelAndView formInseriscicorso() {
		log.info("siamo nella form inserisci corso");
		ModelAndView mv = new ModelAndView("form-inseriscicorso", "corsodilaurea", new CorsoDiLaurea());
		return mv;
	}
	@PostMapping("/post-inseriscicorso")
	public ModelAndView postInserisciCorso(@Valid @ModelAttribute CorsoDiLaurea corso,BindingResult result) {
		if(result.hasErrors()) {
			return new ModelAndView("error",HttpStatus.BAD_REQUEST);
		}
		log.info("siamo nella post inserisci corso");
		ss.inserisciCorso(corso);
		log.debug("i dati dell'utente sono " + " " + corso.getNomeCorso()+ " "+ corso.getCodice());
		ModelAndView mv = new ModelAndView("redirect:/elenco-corso");
		return mv;
	}

	@GetMapping("/elenco-corso")
	public ModelAndView elencoCorso() {
		ModelAndView mv = new ModelAndView("elenco-corso");
		mv.addObject("elencoCorso", ss.getAllCorsi());
		return mv;
	}
	
	@GetMapping("/form-modificacorso/{codice}")
	public ModelAndView formModificaCorso(@PathVariable ("codice") String codice) {
		log.info("siamo nell'elenco dei corsi");
		ModelAndView mv = new ModelAndView("form-modificacorso", "corsodilaurea", ss.trovaCorsoid(codice));
		mv.addObject("elencoCorso", ss.getAllCorsi());
		return mv;
	}
	
	
	
	
	@GetMapping("/put-modificacorso")
	public ModelAndView putModificaCorso(@Valid @ModelAttribute CorsoDiLaurea corso,BindingResult result) {
		if(result.hasErrors()) {
			return new ModelAndView("erroremodifica",HttpStatus.BAD_REQUEST);
		}
		log.info("siamo nella post modifica corsi");
		ss.modificaCorso(corso);
		log.debug("i dati della modifica del corso sono " + " " + corso.getNomeCorso()+ " "+ corso.getCodice());
		ModelAndView mv = new ModelAndView("redirect:/elenco-corso");
		
		return mv;
	}
	
	@GetMapping("/form-eliminacorso/{codice}")	
	public ModelAndView formEliminaCorso(@PathVariable ("codice") String codice) {
		ModelAndView mv = new ModelAndView("form-eliminacorso", "corsodilaurea", ss.trovaCorsoid(codice));
		mv.addObject("elencoCorso", ss.getAllCorsi());
		return mv;
	}
	@GetMapping("/delete-eliminacorso")
	public ModelAndView deleteEliminaCorso(@ModelAttribute CorsoDiLaurea corso,BindingResult result) {
		if(result.hasErrors()) {
			return new ModelAndView("erroreelimina",HttpStatus.BAD_REQUEST);
		}
		ss.eliminaCorso(corso);
		ModelAndView mv = new ModelAndView("redirect:/elenco-corso");
		
		return mv;
	}

	

}
