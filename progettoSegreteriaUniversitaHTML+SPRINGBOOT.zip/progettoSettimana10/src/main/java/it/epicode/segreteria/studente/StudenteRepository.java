package it.epicode.segreteria.studente;

import org.springframework.data.repository.CrudRepository;

public interface StudenteRepository extends CrudRepository<Studente, String> {

}
