package it.epicode.segreteria.exception;

public class AlreadyFoundException extends Exception {

	public AlreadyFoundException(String message) {
		super(message);
		
	}
	

}
