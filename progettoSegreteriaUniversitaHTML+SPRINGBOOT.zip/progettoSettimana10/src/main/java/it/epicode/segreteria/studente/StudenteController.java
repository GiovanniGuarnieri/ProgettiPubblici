package it.epicode.segreteria.studente;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.servlet.ModelAndView;

import it.epicode.segreteria.exception.AlreadyFoundException;
import it.epicode.segreteria.services.SegreteriaService;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class StudenteController {

	@Autowired
	SegreteriaService ss;
	
	@GetMapping("/home")
	public ModelAndView home() {
		log.info("siamo nella home");
		ModelAndView mv = new ModelAndView("home");
		return mv;
		
	}
	
	@GetMapping("/form-inseriscistudente")
	public ModelAndView formInserisciStudente() {
		log.info("siamo nella form-inserisci studente");
		ModelAndView mv = new ModelAndView("form-inseriscistudente", "studente", new Studente());
		mv.addObject("elencoCorso", ss.getAllCorsi());
		return mv;
	}
	
	
	
	@PostMapping("/post-inseriscistudente")
	public ModelAndView postInserisciStudente(@Valid  @ModelAttribute Studente studente,BindingResult result) {
		
		if(result.hasErrors()) {
			
			return new ModelAndView("error",HttpStatus.BAD_REQUEST);
		}
		log.info("siamo nella post-inserisci studente");
		log.debug("i dati dell'utente sono " + " " + studente.getNome()+ " "+ studente.getMatricola());
		try {
			log.trace("cerco di inserire lo studente");
			ss.inserisciStudente(studente);
			log.trace("studente inserito");
		} catch (AlreadyFoundException e) {
			ModelAndView mv1 = new ModelAndView("error");
			mv1.addObject("errore", e.getMessage());
			log.debug(e.getMessage());
			return mv1;
		}
		
		ModelAndView mv = new ModelAndView("redirect:/elenco-studenti");
	
		
		return mv;
	}
	
	
	
	
	@GetMapping("/elenco-studenti")
	public ModelAndView elencoStudenti() {
		ModelAndView mv = new ModelAndView("elenco-studenti");
		mv.addObject("elencoStudenti", ss.getAllStudenti());
		return mv;
	}
	
	
	
	
	
	
	
	
	
	@GetMapping("/form-modificastudente/{matricola}")
	public ModelAndView formModificaStudente(@PathVariable ("matricola") String matricola) {
		ModelAndView mv = new ModelAndView("form-modificastudente", "studente", ss.trovaStudenteid(matricola));
		log.debug("l'utente trovato e:" + ss.trovaStudenteid(matricola));
		mv.addObject("elencoCorso", ss.getAllCorsi());
	
		
		return mv;
	}
	
	@GetMapping("/put-modificastudente")
	public ModelAndView postModificaStudente(@Valid @ModelAttribute Studente studente,BindingResult result) {
		if(result.hasErrors()) {
			return new ModelAndView("erroremodifica",HttpStatus.BAD_REQUEST);
		}
		ss.modificaStudente(studente);
		ModelAndView mv = new ModelAndView("redirect:/elenco-studenti");
		
		return mv;
	}
	
	
	

	
@GetMapping("/form-eliminastudente/{matricola}")	
public ModelAndView formEliminaStudente(@PathVariable ("matricola") String matricola) {
	ModelAndView mv = new ModelAndView("form-eliminastudente", "studente", ss.trovaStudenteid(matricola));
	mv.addObject("elencoStudenti", ss.getAllStudenti());
	return mv;
}
@GetMapping("/delete-eliminastudente")
public ModelAndView deleteEliminaStudente(  @ModelAttribute Studente studente,BindingResult result) {
	if(result.hasErrors()) {
		return new ModelAndView("erroreelimina",HttpStatus.BAD_REQUEST);
	}
	ss.eliminaStudente(studente);
	ModelAndView mv = new ModelAndView("redirect:/elenco-studenti");
	
	return mv;
}


}
	
	
	
	

	
	
	
	
	



