package it.epicode.segreteria.corsodilaurea;

import org.springframework.data.repository.CrudRepository;

public interface CorsoDiLaureaRepository extends CrudRepository<CorsoDiLaurea, String> {

}
