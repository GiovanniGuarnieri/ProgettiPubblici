package it.epicode.azienda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Azienda1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
