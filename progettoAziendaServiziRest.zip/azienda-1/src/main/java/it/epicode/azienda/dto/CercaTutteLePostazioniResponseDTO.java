package it.epicode.azienda.dto;

import java.util.List;


import it.epicode.azienda.model.Postazione;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class CercaTutteLePostazioniResponseDTO {
	private int PostazioneTrovata;
	List<Postazione>elencoPostazione;
}
