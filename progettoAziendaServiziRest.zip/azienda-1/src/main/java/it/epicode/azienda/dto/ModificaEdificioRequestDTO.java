package it.epicode.azienda.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ModificaEdificioRequestDTO {
	private String nomeCitta;
	private String nome;
	private String indirizzo;
}
