package it.epicode.azienda.dto;

import javax.validation.constraints.NotBlank;

import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class ModificaUtenteRequestDTO {

	@NotBlank(message = "username necessario")
	private String username;
	@NotBlank(message = "nome necessario")
	private String nome;
	private String email;
	private String password;
}
