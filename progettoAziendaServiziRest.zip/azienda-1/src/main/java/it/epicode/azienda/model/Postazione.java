package it.epicode.azienda.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.Max;

import com.fasterxml.jackson.annotation.JsonIgnore;

import it.epicode.azienda.controller.Tipo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Postazione {

	@Id
	private String codice;
	private String descrizione;
	@Enumerated(EnumType.STRING)
	private Tipo tipo;
	@Max(10)
	private int occupanti;
	@ManyToOne(cascade = CascadeType.ALL)
	@EqualsAndHashCode.Exclude
	@ToString.Exclude
	@JoinColumn(name = "nome_edificio")
	private Edificio edificio;
	@EqualsAndHashCode.Exclude
	@ToString.Exclude
	@OneToMany(mappedBy = "postazione", cascade = CascadeType.ALL)
	@JsonIgnore
	private List<Prenotazione> prenotazione = new ArrayList<>();
	
	
	
	
}
