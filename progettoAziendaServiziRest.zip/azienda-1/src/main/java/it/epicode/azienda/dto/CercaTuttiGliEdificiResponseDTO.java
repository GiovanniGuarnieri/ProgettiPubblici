package it.epicode.azienda.dto;

import java.util.List;

import it.epicode.azienda.model.Citta;
import it.epicode.azienda.model.Edificio;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class CercaTuttiGliEdificiResponseDTO {
	private int edificiTrovati;
	List<Edificio>elencoEdifici;
}
