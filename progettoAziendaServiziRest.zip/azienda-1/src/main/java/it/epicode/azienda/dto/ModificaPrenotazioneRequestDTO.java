package it.epicode.azienda.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ModificaPrenotazioneRequestDTO {
	private int id;
	private String codicePostazione;
	private String username;
	private String dataDiPrenotazione;
	private String dataPrenotata;
	
}
