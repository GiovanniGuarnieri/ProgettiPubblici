package it.epicode.azienda.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InserisciCittaRequestDTO {
	private String nome;
	private int cap;
}
