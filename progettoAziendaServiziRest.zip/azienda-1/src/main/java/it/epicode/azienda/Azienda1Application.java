package it.epicode.azienda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Azienda1Application {

	public static void main(String[] args) {
		SpringApplication.run(Azienda1Application.class, args);
	}

}
