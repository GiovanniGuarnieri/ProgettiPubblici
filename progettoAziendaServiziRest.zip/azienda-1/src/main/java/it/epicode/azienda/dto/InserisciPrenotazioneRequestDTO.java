package it.epicode.azienda.dto;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotBlank;

import it.epicode.azienda.model.Edificio;
import it.epicode.azienda.model.Postazione;
import it.epicode.azienda.model.Prenotazione;
import it.epicode.azienda.model.Utente;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InserisciPrenotazioneRequestDTO {
	
	private String codicePostazione;
	private String username;
	private String dataDiPrenotazione;
	private String dataPrenotata;
	
	
	
	
	
	
}
