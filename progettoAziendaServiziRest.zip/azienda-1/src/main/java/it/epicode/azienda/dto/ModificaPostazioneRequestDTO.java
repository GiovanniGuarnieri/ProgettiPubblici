package it.epicode.azienda.dto;

import javax.validation.constraints.NotBlank;

import it.epicode.azienda.controller.Tipo;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ModificaPostazioneRequestDTO {
	@NotBlank
	private String codice;
	private String descrizione;
	private int occupanti;
	private Tipo tipo;
	@NotBlank
	private String nomeEdificio;
}
