package it.epicode.azienda.errors;

public class NotFoundException extends Exception {

	public NotFoundException(String message) {
		super(message);
		
	}

}
