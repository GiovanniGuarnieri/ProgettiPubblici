package it.epicode.azienda.dto;

import java.util.List;

import it.epicode.azienda.model.Citta;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class CercaTutteLeCittaResponseDTO {
	private int cittaTrovate;
	List<Citta>elencoCitta;
}
