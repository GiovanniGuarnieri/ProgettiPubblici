package it.epicode.azienda.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Edificio {
	@Id
	private String nome;
	private String indirizzo;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "nome_citta")
	private Citta citta;
	@OneToMany(mappedBy = "edificio",cascade = CascadeType.ALL)
	@JsonIgnore
	private List<Postazione>postazioni = new ArrayList <>();
	
}
