package it.epicode.azienda.repository;

import org.springframework.data.repository.CrudRepository;

import it.epicode.azienda.model.Postazione;

public interface PostazioneRepository extends CrudRepository<Postazione, String> {

}
