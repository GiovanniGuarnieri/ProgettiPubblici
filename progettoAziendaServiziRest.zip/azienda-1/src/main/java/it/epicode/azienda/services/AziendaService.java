package it.epicode.azienda.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import it.epicode.azienda.dto.CercaTutteLeCittaResponseDTO;
import it.epicode.azienda.dto.CercaTutteLePostazioniResponseDTO;
import it.epicode.azienda.dto.CercaTutteLePrenotazioniResponseDTO;
import it.epicode.azienda.dto.CercaTuttiGliEdificiResponseDTO;
import it.epicode.azienda.dto.CercaTuttiGliUtentiDTO;
import it.epicode.azienda.dto.InserisciCittaRequestDTO;
import it.epicode.azienda.dto.InserisciEdificioRequestDTO;
import it.epicode.azienda.dto.InserisciPostazioneRequestDTO;
import it.epicode.azienda.dto.InserisciPrenotazioneRequestDTO;
import it.epicode.azienda.dto.InserisciUtenteRequestDTO;
import it.epicode.azienda.dto.ModificaCittaRequestDTO;
import it.epicode.azienda.dto.ModificaEdificioRequestDTO;
import it.epicode.azienda.dto.ModificaPostazioneRequestDTO;
import it.epicode.azienda.dto.ModificaPrenotazioneRequestDTO;
import it.epicode.azienda.dto.ModificaUtenteRequestDTO;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.model.Citta;
import it.epicode.azienda.model.Edificio;
import it.epicode.azienda.model.Postazione;
import it.epicode.azienda.model.Prenotazione;
import it.epicode.azienda.model.Utente;
import it.epicode.azienda.repository.CittaRepository;
import it.epicode.azienda.repository.EdificioRepository;
import it.epicode.azienda.repository.PostazioneRepository;
import it.epicode.azienda.repository.PrenotazioneRepository;
import it.epicode.azienda.repository.UtenteRepository;
import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class AziendaService {


	@Autowired
	PrenotazioneRepository pr;
	@Autowired
	UtenteRepository ur;
	@Autowired
	PostazioneRepository prr;
	@Autowired
	EdificioRepository er;
	@Autowired
	CittaRepository cr;




	public boolean inserisciPrenotazione(InserisciPrenotazioneRequestDTO dto) {
		Prenotazione p = new Prenotazione();
		BeanUtils.copyProperties(dto, p);
		Utente u  = ur.findById(dto.getUsername()).get();
		p.setUtente(u);
		u.getPrenotazione().add(p);
		Postazione po = prr.findById(dto.getCodicePostazione()).get();
		p.setPostazione(po);
		po.getPrenotazione().add(p);
		pr.save(p);
		return true;
	}



	public boolean inserisciUtente(InserisciUtenteRequestDTO dto) {
		if(!ur.existsById(dto.getUsername())) {
			Utente u = new Utente();
			BeanUtils.copyProperties(dto, u);
			String hash = BCrypt.hashpw(dto.getPassword(), BCrypt.gensalt());
			u.setPassword(hash);
			ur.save(u);
			return true;}
		else {
			return false;
		}

	}


	public boolean inserisciEdificio(InserisciEdificioRequestDTO dto) {
		if(!er.existsById(dto.getNome())) {
			Edificio e = new Edificio();
			BeanUtils.copyProperties(dto, e);
			Citta c = cr.findById(dto.getNomeCitta()).get();
			e.setCitta(c);
			c.getEdificio().add(e);
			er.save(e);
			return true;}
		else {
			return false;
		}
	}
	public boolean inserisciCitta(InserisciCittaRequestDTO dto) {
		if(!cr.existsById(dto.getNome())) {
			Citta c = new Citta();
			BeanUtils.copyProperties(dto, c);
			cr.save(c);
			return true;}
		else {
			return false;
		}
	}
	public boolean inserisciPostazione(InserisciPostazioneRequestDTO dto) {
		if(!prr.existsById(dto.getCodice())) {
			log.info("-------------------------" + dto.getCodice());
			Postazione p = new Postazione();
			BeanUtils.copyProperties(dto, p);
			Edificio e = er.findById(dto.getNomeEdificio()).get();
			p.setEdificio(e);
			e.getPostazioni().add(p);
			prr.save(p);
			return true;}
		else {
			return false;
		}

	}

	public CercaTutteLeCittaResponseDTO trovaTutteLeCitta() {
		CercaTutteLeCittaResponseDTO dto = new CercaTutteLeCittaResponseDTO ();
		List<Citta> lc = (List)cr.findAll(); 
		if(lc.size()> 0) {
			dto.setCittaTrovate(lc.size());
			dto.setElencoCitta(lc);
			return dto;
		}
		else {
			new ResponseEntity("nessuna citta trovato", HttpStatus.NOT_FOUND);
			return null;
		}
	}


	public CercaTuttiGliEdificiResponseDTO trovaTuttiGliEdifici() {
		CercaTuttiGliEdificiResponseDTO dto = new CercaTuttiGliEdificiResponseDTO ();
		List<Edificio> le = (List)er.findAll(); 
		if(le.size()> 0) {
			dto.setEdificiTrovati(le.size());
			dto.setElencoEdifici(le);
			return dto;
		}
		else {
			new ResponseEntity("nessuna edificio trovato", HttpStatus.NOT_FOUND);
			return null;
		}
	}

	public CercaTutteLePostazioniResponseDTO trovaTutteLePostazioni() {
		CercaTutteLePostazioniResponseDTO dto = new CercaTutteLePostazioniResponseDTO ();
		List<Postazione> lp = (List)prr.findAll(); 
		if(lp.size()> 0) {
			dto.setPostazioneTrovata(lp.size());
			dto.setElencoPostazione(lp);
			return dto;
		}
		else {
			new ResponseEntity("nessuna postazione trovata", HttpStatus.NOT_FOUND);
			return null;
		}
	}

	public CercaTuttiGliUtentiDTO cercaTuttiGliUtenti() {
		CercaTuttiGliUtentiDTO dto = new CercaTuttiGliUtentiDTO ();
		List<Utente> lu = (List)ur.findAll(); 
		if(lu.size()> 0) {
			dto.setUtentiTrovat(lu.size());
			dto.setElencoUtenti(lu);
			return dto;
		}
		else {
			new ResponseEntity("nessun utenti trovati", HttpStatus.NOT_FOUND);
			return null;
		}
	}

	public CercaTutteLePrenotazioniResponseDTO cercaTutteLePrenotazioni() {
		CercaTutteLePrenotazioniResponseDTO  dto = new CercaTutteLePrenotazioniResponseDTO  ();
		List<Prenotazione> lp = (List)pr.findAll(); 
		if(lp.size()> 0) {
			dto.setPrenotazioniTrovate(lp.size());
			dto.setElencoPrenotazioni(lp);
			return dto;
		}
		else {
			new ResponseEntity("nessuna prenotazioni  trovata", HttpStatus.NOT_FOUND);
			return null;
		}
	}



	public boolean eliminaUtente(String username) {
		if(ur.existsById(username)) {
			ur.deleteById(username);
			return true;
		}
		else{return false;}

	}

	public boolean eliminaPrenotazione(int id) {
		if(pr.existsById(id)) {
			pr.deleteById(id);
			return true;
		}
		else{return false;}

	}
	public boolean eliminaPostazione(String codice) {
		if(prr.existsById(codice)) {
			prr.deleteById(codice);
			return true;
		}
		else {
			return false;
		}
	}

	public boolean eliminaCitta(String nome) {
		if(cr.existsById(nome)) {
			cr.deleteById(nome);
			return true;
		}
		else {
			return false;
		}
	}

		
	public void eliminaEdificio(String nome) {
		er.findById(nome).orElseThrow();
		er.deleteById(nome);
	}
	
	
	
	public boolean modificaUtente(ModificaUtenteRequestDTO dto) {
		if(ur.existsById(dto.getUsername())) {
			Utente u = ur.findById(dto.getUsername()).get();
			BeanUtils.copyProperties(dto, u);
			String hash = BCrypt.hashpw(dto.getPassword(), BCrypt.gensalt());
			u.setPassword(hash);
			ur.save(u);
			return true;}
		else {
			return false;
		}
	}




	public boolean modificaCitta(ModificaCittaRequestDTO dto) {
		if(cr.existsById(dto.getNome())) {
			Citta c = cr.findById(dto.getNome()).get();
			BeanUtils.copyProperties(dto, c);
			cr.save(c);
			return true;}
		else {
			return false;
		}
	}

	public void modificaCitta2(ModificaCittaRequestDTO dto) throws NotFoundException {
		if(cr.existsById(dto.getNome())) {
			Citta c = cr.findById(dto.getNome()).get();
			BeanUtils.copyProperties(dto, c);
			cr.save(c);
			}
		else { throw new NotFoundException("citta non boooooo trovata");
			
		}
	}
	
	public void modificaCitta3(ModificaCittaRequestDTO dto) throws NotFoundException {
	 Citta c = cr.findById(dto.getNome()).orElseThrow(()->new NotFoundException("citta non trovata"));
	 cr.save(c);
	}


	public boolean modificaEdificio(ModificaEdificioRequestDTO dto) {
		if(er.existsById(dto.getNome())) {
			Edificio e = er.findById(dto.getNome()).get();
			BeanUtils.copyProperties(dto, e);
			Citta c = cr.findById(dto.getNomeCitta()).get();
			e.setCitta(c);
			c.getEdificio().add(e);
			er.save(e);
			return true;}
		else {
			return false;
		}
	}
	public boolean modificaPostazione(ModificaPostazioneRequestDTO dto) {
		if(prr.existsById(dto.getCodice())) {
			log.info("-------------------------" + dto.getCodice());
			Postazione p = prr.findById(dto.getCodice()).get();
			BeanUtils.copyProperties(dto, p);
			Edificio e = er.findById(dto.getNomeEdificio()).get();
			p.setEdificio(e);
			e.getPostazioni().add(p);
			prr.save(p);
			return true;}
		else {
			return false;
		}
	}

	public boolean modificaPrenotazione(ModificaPrenotazioneRequestDTO dto) {
		if(pr.existsById(dto.getId())) {
			Prenotazione p = pr.findById(dto.getId()).get();
			BeanUtils.copyProperties(dto, p);
			Utente u  = ur.findById(dto.getUsername()).get();
			p.setUtente(u);
			u.getPrenotazione().add(p);
			Postazione po = prr.findById(dto.getCodicePostazione()).get();
			p.setPostazione(po);
			po.getPrenotazione().add(p);
			pr.save(p);
			return true;
		}
		else {
			return false;
		}

	}

}

