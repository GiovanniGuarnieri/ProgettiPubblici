package it.epicode.azienda.dto;

import java.util.List;


import it.epicode.azienda.model.Prenotazione;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class CercaTutteLePrenotazioniResponseDTO {
	private int prenotazioniTrovate;
	List <Prenotazione>elencoPrenotazioni;

}
