package it.epicode.azienda.runner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Component;



import java.util.ArrayList;




import it.epicode.azienda.controller.Tipo;
import it.epicode.azienda.model.Citta;
import it.epicode.azienda.model.Edificio;
import it.epicode.azienda.model.Postazione;
import it.epicode.azienda.model.Utente;
import it.epicode.azienda.repository.CittaRepository;
import it.epicode.azienda.repository.EdificioRepository;
import it.epicode.azienda.repository.PostazioneRepository;
import it.epicode.azienda.repository.PrenotazioneRepository;
import it.epicode.azienda.repository.UtenteRepository;

@Component
public class AziendaRunner implements CommandLineRunner {

	@Autowired
	CittaRepository cr;
	@Autowired
	EdificioRepository er;
	@Autowired
	PostazioneRepository pr;
	@Autowired
	PrenotazioneRepository pc;
	@Autowired
	UtenteRepository ur;

	
	@Override
	public void run(String... args) throws Exception {
		String hash = BCrypt.hashpw("ciao", BCrypt.gensalt());

		
		ur.save(Utente.builder().nome("Francesco").email("Fran@gmail.com").username("Frans").password(hash).build());
		ur.save(Utente.builder().nome("Luca").email("Luc@gmail.com").username("Lucas").password(BCrypt.hashpw("no", BCrypt.gensalt())).build());
		
		Citta Fano = (Citta.builder().edificio(new ArrayList<>()).nome("Fano").cap(60220).build());
		Citta Pesaro = (Citta.builder().edificio(new ArrayList<>()).nome("Pesaro").cap(6340).build());
		
		
		Edificio edificio1 = Edificio.builder().postazioni(new ArrayList<>()).nome("Girasoli").indirizzo("LocalitÃ  la Capannella").citta(Fano).build();
		Edificio edificio2 = Edificio.builder().postazioni(new ArrayList<>()).nome("Mattatoio").indirizzo("Vicino le tre croci").citta(Pesaro).build();
		Fano.getEdificio().add(edificio2);
		Pesaro.getEdificio().add(edificio1);
		
		
		Postazione post1 = Postazione.builder().codice("001").descrizione("Sala preghiera").tipo(Tipo.PRIVATO).occupanti(6).edificio(edificio2).build();
		Postazione post2 = Postazione.builder().codice("002").descrizione("Sala random").tipo(Tipo.OPENSPACE).occupanti(5).edificio(edificio1).build();
		edificio2.getPostazioni().add(post1);
		edificio1.getPostazioni().add(post2);
		
		pr.save(post1);
		pr.save(post2);
		
	}

	
	
	
	
	
}