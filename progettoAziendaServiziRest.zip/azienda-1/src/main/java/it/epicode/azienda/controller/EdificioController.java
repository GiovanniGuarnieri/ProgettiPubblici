package it.epicode.azienda.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import it.epicode.azienda.dto.InserisciEdificioRequestDTO;
import it.epicode.azienda.dto.InserisciPostazioneRequestDTO;
import it.epicode.azienda.dto.ModificaCittaRequestDTO;
import it.epicode.azienda.dto.ModificaEdificioRequestDTO;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.services.AziendaService;
@RestController
@RequestMapping("/edificio")
public class EdificioController {

	
	
	@Autowired
	AziendaService as;
	
	@Operation (summary = "Inserisce una edificio nel db", description = "inserisce una edificio nel db ")
	@ApiResponse(responseCode = "200" , description = "edificio inserito con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@PostMapping(path = "/inserisciEdificio" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisciEdificio(@Valid @RequestBody InserisciEdificioRequestDTO dto) {
		if(as.inserisciEdificio(dto)) {
			return ResponseEntity.ok("edificio inserita");}
		else {return new ResponseEntity("errore nell'inserimento", HttpStatus.FAILED_DEPENDENCY);}
	}
	
	
	
	@Operation (summary = "ritorna tutti gli edifici nel db", description = "ritorna un elenco di edifici ")
	@ApiResponse(responseCode = "200" , description = "elenco edifici del db  !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@GetMapping ("/tuttiGliEdifici")
	public ResponseEntity tutteGliEdifici() {
		return ResponseEntity.ok(as.trovaTuttiGliEdifici());
	}
	
	
	@Operation (summary = "Inserisce una edificio nel db ", description = "inserisce un edificio nel db con gestione di errore centralizzata")
	@ApiResponse(responseCode = "200" , description = "edificio inserito con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@PostMapping(path = "/inserisciEdificioProva" )
	public ResponseEntity inserisciEdificioProva(@Valid @RequestBody InserisciEdificioRequestDTO dto) {
		if(as.inserisciEdificio(dto)) {
			return ResponseEntity.ok("edificio inserita");}
		else {return new ResponseEntity("errore nell'inserimento", HttpStatus.FAILED_DEPENDENCY);}
	}
	
	
	@Operation (summary = "elimina un edificio nel db ", description = "elimina un edificio nel db attraverso l'id")
	@ApiResponse(responseCode = "200" , description = "edificio eliminato con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@DeleteMapping("/elimina/{nome}")
	public ResponseEntity eliminaEdificio(@PathVariable("nome") String nome)  {
		as.eliminaEdificio(nome);
		return ResponseEntity.ok("edificio eliminato con successo");
	
	}
	@Operation (summary = "Modifica un edificio nel db ", description = "Modifico un edificio nel db")
	@ApiResponse(responseCode = "200" , description = "edificio modificato con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@PutMapping(path = "/modificaedificio" )
	public ResponseEntity ModificaEdificio(@Valid @RequestBody ModificaEdificioRequestDTO dto) {
		if(as.modificaEdificio(dto)) {
			return ResponseEntity.ok("edificio modificata");}
		else {return new ResponseEntity("errore nella modifica", HttpStatus.FAILED_DEPENDENCY);}
	}
}