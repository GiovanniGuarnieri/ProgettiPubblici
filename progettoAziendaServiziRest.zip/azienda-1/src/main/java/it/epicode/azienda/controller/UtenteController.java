package it.epicode.azienda.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import it.epicode.azienda.dto.InserisciUtenteRequestDTO;
import it.epicode.azienda.dto.ModificaUtenteRequestDTO;
import it.epicode.azienda.services.AziendaService;
@RestController
@RequestMapping("/utente")
public class UtenteController {
	@Autowired
	AziendaService as;

	
	/**
	 * inserimento di un utente con metodo POST
	 * @param dto
	 * @param errori
	 * @return
	 */
	@Operation (summary = "Inserisce un utente nel db ", description = "inserisce un utente nel db ")
	@ApiResponse(responseCode = "200" , description = "utente inserito con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@PostMapping(path = "/inserisciUtente" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisciUtente(@Valid @RequestBody InserisciUtenteRequestDTO dto, BindingResult errori) {

		if(errori.hasErrors()) {
			List<String> descrizioneDiErrore = new ArrayList<String>();
			for(ObjectError e : errori.getAllErrors()) {
				descrizioneDiErrore.add(e.getDefaultMessage());
			}
			return new ResponseEntity(descrizioneDiErrore , HttpStatus.BAD_REQUEST);
		}
		if(as.inserisciUtente(dto)) {
			return ResponseEntity.ok("utente inserito");}
		else {return new ResponseEntity("errore nell'inserimento", HttpStatus.FAILED_DEPENDENCY);}
	}
	
	
	/**
	 * metodo che ritorna la lista di utenti presenti nel db tramite il metodo GET
	 * @return
	 */
	@Operation (summary = "ritorna un elenco di utenti presenti nel db ", description = "ritorna un elenco di utenti prenseti nel db")
	@ApiResponse(responseCode = "200" , description = "edificio inserito con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@GetMapping ("/tuttigliutenti")
	public ResponseEntity tuttiGliUtenti() {
		return ResponseEntity.ok(as.cercaTuttiGliUtenti());
	}
	/**
	 * Eliminazione di un utente nel db attraverso il MAPPING DELETE
	 * @param username
	 * @return
	 */
	@Operation (summary = "elimina un utente nel db ", description = "elimina un utente nel db")
	@ApiResponse(responseCode = "200" , description = "edificio inserito con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@DeleteMapping("/elimina/{username}")
	public ResponseEntity eliminaUtente(@PathVariable("username") String username) {
		if(as.eliminaUtente(username)) {
			return ResponseEntity.ok("utente eliminto");}
		else {
			return new ResponseEntity("utente non trovateo", HttpStatus.NOT_FOUND);
		}

	}

	
	/**
	 * Inserimenti di un utente nel db con la gestione di errore centralizzata col mapping POST
	 * @param dto
	 * @return
	 */
	@Operation (summary = "Inserisce una Utente nel db ", description = "inserisce un utente nel db con gestione di errore centralizzata")
	@ApiResponse(responseCode = "200" , description = "utente inserito con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@PostMapping(path = "/inserisciUtenteTest" )
	public ResponseEntity inserisciUtenteTest(@Valid @RequestBody InserisciUtenteRequestDTO dto) {
		if(as.inserisciUtente(dto)) {
			return ResponseEntity.ok("utente inserito");}
		else {return new ResponseEntity("errore nell'inserimento", HttpStatus.FAILED_DEPENDENCY);}
	}

	/**Modifica un utente nel db attraverso il  mapping put
	 * 
	 * @param dto
	 * @return
	 */
	@Operation (summary = "modifica un utente  nel db ", description = "modifica un utente nel db con gestione di errore centralizzata")
	@ApiResponse(responseCode = "200" , description = "edificio inserito con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@PutMapping(path = "/modificaUtente" )
	public ResponseEntity ModificaUtente(@Valid @RequestBody ModificaUtenteRequestDTO dto) {
		if(as.modificaUtente(dto)) {
			return ResponseEntity.ok("utente modificato");}
		else {return new ResponseEntity("errore nella modifica", HttpStatus.FAILED_DEPENDENCY);}
	}


}
