package it.epicode.azienda.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import it.epicode.azienda.dto.InserisciPostazioneRequestDTO;
import it.epicode.azienda.dto.ModificaCittaRequestDTO;
import it.epicode.azienda.dto.ModificaPostazioneRequestDTO;
import it.epicode.azienda.services.AziendaService;
@RestController
@RequestMapping("/postazione")
public class PostazioneController {

	
	
	@Autowired
	AziendaService as;
	
	
	@Operation (summary = "Inserisce una Postazione nel db ", description = "inserisce una postazione nel db ")
	@ApiResponse(responseCode = "200" , description = "edificio inserito con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@PostMapping(path = "/inserisciPostazione")
	public ResponseEntity inserisciPostazione(@Valid @RequestBody InserisciPostazioneRequestDTO dto, BindingResult errori) {

		if(errori.hasErrors()) {
			List<String> descrizioneDiErrore = new ArrayList<String>();
			for(ObjectError e : errori.getAllErrors()) {
				descrizioneDiErrore.add(e.getDefaultMessage());
			}
			return new ResponseEntity(descrizioneDiErrore , HttpStatus.BAD_REQUEST);
		}
		if(as.inserisciPostazione(dto)) {
			return ResponseEntity.ok("postazione inserita");}
		else {return new ResponseEntity("errore nell'inserimento", HttpStatus.FAILED_DEPENDENCY);}
	}
	
	
	
	@Operation (summary = "ritorna la lista delle postazioni ", description = "ritorna la lista delle postazione all'interno del db")
	@ApiResponse(responseCode = "200" , description = "elenco postazione nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@GetMapping ("/tutteLePostazioni")
	public ResponseEntity tutteLePostazioni() {
		return ResponseEntity.ok(as.trovaTutteLePostazioni());
	}
	
	
	
	
	@Operation (summary = "elimina una postazione  nel db ", description = "elimina una postazione")
	@ApiResponse(responseCode = "200" , description = "eliminazione avvenuta con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@DeleteMapping("/elimina/{codice}")
	public ResponseEntity eliminaPostazione(@PathVariable("codice") String codice) {
		if(as.eliminaPostazione(codice)) {
		return ResponseEntity.ok("postazione eliminata");}
		else {
			return new ResponseEntity("postazione non trovata", HttpStatus.NOT_FOUND);
		}
	}
	
	
	
	@Operation (summary = "Modifica  una postazione nel db ", description = "Modifica ua postazione nel db con gestione di errore centralizzata")
	@ApiResponse(responseCode = "200" , description = "edificio modificato con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@PutMapping(path = "/modificaPostazione" )
	public ResponseEntity ModificaPostazione(@Valid @RequestBody ModificaPostazioneRequestDTO dto) {
		if(as.modificaPostazione(dto)) {
			return ResponseEntity.ok("Postazione modificata");}
		else {return new ResponseEntity("errore nella modifica", HttpStatus.FAILED_DEPENDENCY);}
	}

}
