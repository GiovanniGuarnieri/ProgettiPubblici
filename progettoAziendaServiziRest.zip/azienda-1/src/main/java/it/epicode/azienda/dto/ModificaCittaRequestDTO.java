package it.epicode.azienda.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ModificaCittaRequestDTO {
	@NotBlank
	private String nome;
	@NotNull
	private int cap;
}
