package it.epicode.azienda.dto;

import javax.validation.constraints.NotBlank;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InserisciEdificioRequestDTO {
	
	
	@NotBlank(message = "nomeCitta necessario")
	private String nomeCitta;
	private String nome;
	private String indirizzo;
	
	
	
}
