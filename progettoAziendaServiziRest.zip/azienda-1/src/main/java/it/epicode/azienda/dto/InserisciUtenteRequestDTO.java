package it.epicode.azienda.dto;

import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotBlank;

import it.epicode.azienda.model.Prenotazione;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class InserisciUtenteRequestDTO {
	@NotBlank(message = "username necessario")
	private String username;
	@NotBlank(message = "nome necessario")
	private String nome;
	private String email;
	private String password;
}
