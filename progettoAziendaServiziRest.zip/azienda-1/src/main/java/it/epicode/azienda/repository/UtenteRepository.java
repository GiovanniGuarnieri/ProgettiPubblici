package it.epicode.azienda.repository;

import org.springframework.data.repository.CrudRepository;

import it.epicode.azienda.model.Utente;

public interface UtenteRepository extends CrudRepository<Utente, String> {

}
