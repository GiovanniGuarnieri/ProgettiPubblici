package it.epicode.azienda.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import it.epicode.azienda.dto.InserisciPrenotazioneRequestDTO;
import it.epicode.azienda.dto.ModificaCittaRequestDTO;
import it.epicode.azienda.dto.ModificaPrenotazioneRequestDTO;
import it.epicode.azienda.services.AziendaService;



@RestController
@RequestMapping("/prenotazione")
public class PrenotazioneController {
	@Autowired
	AziendaService as;
	
	@Operation (summary = "Inserisce una Prenotazione nel db ", description = "inserisce una Prenotazione nel db con gestione di errore centralizzata")
	@ApiResponse(responseCode = "200" , description = "Prenotazione inserito con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@PostMapping(path = "/inserisciPrenotazione" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisciPrenotazione(@Valid @RequestBody InserisciPrenotazioneRequestDTO dto, BindingResult errori) {

		if(errori.hasErrors()) {
			List<String> descrizioneDiErrore = new ArrayList<String>();
			for(ObjectError e : errori.getAllErrors()) {
				descrizioneDiErrore.add(e.getDefaultMessage());
			}
			return new ResponseEntity(descrizioneDiErrore , HttpStatus.BAD_REQUEST);
		}
		if(as.inserisciPrenotazione(dto)) {
			return ResponseEntity.ok("prenotazione inserita");}
		else {return new ResponseEntity("errore nell'inserimento", HttpStatus.FAILED_DEPENDENCY);}
	}
	
	
	@Operation (summary = "ritorna una elenco di prenotazioni presenti nel db ", description = "ritorna un elenco di prenotazioni presenti nel db")
	@ApiResponse(responseCode = "200" , description = "edificio inserito con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@GetMapping ("/tutteleprenotazioni")
	public ResponseEntity tutteLePrenotazioni() {
		return ResponseEntity.ok(as.cercaTutteLePrenotazioni());
	}
	
	@Operation (summary = "elimina una edificio nel db ", description = "elimina un edificio nel db con gestione di errore centralizzata")
	@ApiResponse(responseCode = "200" , description = "edificio inserito con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@DeleteMapping("/elimina/{id}")
	public ResponseEntity eliminaPrenotazione(@PathVariable("id") int id) {
		if(as.eliminaPrenotazione(id)) {
		return ResponseEntity.ok("prenotazione eliminata");}
		else {
			return new ResponseEntity("prenotazione non trovata", HttpStatus.NOT_FOUND);
		}
	}
	@Operation (summary = "modifica una edificio nel db ", description = "modifica un edificio nel db con gestione di errore centralizzata")
	@ApiResponse(responseCode = "200" , description = "edificio inserito con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@PutMapping(path = "/modificaPrenotazione" )
	public ResponseEntity ModificaPrenotazione(@Valid @RequestBody ModificaPrenotazioneRequestDTO dto) {
		if(as.modificaPrenotazione(dto)) {
			return ResponseEntity.ok("prenotazione modificata");}
		else {return new ResponseEntity("errore nella modifica", HttpStatus.FAILED_DEPENDENCY);}
	}

}
