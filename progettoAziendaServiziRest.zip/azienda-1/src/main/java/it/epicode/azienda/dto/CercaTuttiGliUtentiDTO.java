package it.epicode.azienda.dto;

import java.util.List;

import it.epicode.azienda.model.Citta;
import it.epicode.azienda.model.Utente;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class CercaTuttiGliUtentiDTO {
	private int UtentiTrovat;
	List<Utente>elencoUtenti;
}
