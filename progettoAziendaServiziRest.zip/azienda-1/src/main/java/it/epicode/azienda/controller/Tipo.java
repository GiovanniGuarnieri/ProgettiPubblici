package it.epicode.azienda.controller;

public enum Tipo {
	PRIVATO,
	OPENSPACE,
	SALA_RIUNIONI;
	
	
}
