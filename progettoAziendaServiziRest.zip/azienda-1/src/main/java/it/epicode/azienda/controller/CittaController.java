package it.epicode.azienda.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import it.epicode.azienda.dto.InserisciCittaRequestDTO;
import it.epicode.azienda.dto.ModificaCittaRequestDTO;
import it.epicode.azienda.dto.ModificaUtenteRequestDTO;
import it.epicode.azienda.errors.NotFoundException;
import it.epicode.azienda.services.AziendaService;

@RestController
@RequestMapping("/citta")
public class CittaController {
	@Autowired
	AziendaService as;
	
	@Operation (summary = "Inserisce una citta nel db", description = "inserisce una citta nel db ")
	@ApiResponse(responseCode = "200" , description = "citta inserita con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@PostMapping(path = "/inserisciCitta" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisciCitta(@Valid @RequestBody InserisciCittaRequestDTO dto, BindingResult errori) {
		if(as.inserisciCitta(dto)) {
			return ResponseEntity.ok("citta inserita");}
		else {return new ResponseEntity("errore nell'inserimento", HttpStatus.FAILED_DEPENDENCY);}
	}
	
	
	@Operation (summary = "ritorna tutte le citta", description = "ritorna tutte le citta ")
	@ApiResponse(responseCode = "200" , description = "elenco delle citta !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@GetMapping ("/tuttecitta")
	public ResponseEntity tutteLeCitta() {
		return ResponseEntity.ok(as.trovaTutteLeCitta());
	}
	
	
	@Operation (summary = "Elimina una citta nel db", description = "elimina una citta nel db ")
	@ApiResponse(responseCode = "200" , description = "citta eliminata con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@DeleteMapping("/elimina/{nome}")
	public ResponseEntity eliminaCitta(@PathVariable("nome") String nome) {
		if(as.eliminaCitta(nome)) {
			return ResponseEntity.ok("citta eliminto");}
		else {
			return new ResponseEntity("citta non trovata", HttpStatus.NOT_FOUND);
		}

	}
	@Operation (summary = "modifica una citta nel db", description = "modifica una citta nel db ")
	@ApiResponse(responseCode = "200" , description = "citta modifica con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@PutMapping(path = "/modificacitta" )
	public ResponseEntity ModificaCitta(@Valid @RequestBody ModificaCittaRequestDTO dto) {
		if(as.modificaCitta(dto)) {
			return ResponseEntity.ok("citta modificata");}
		else {return new ResponseEntity("errore nella modifica", HttpStatus.FAILED_DEPENDENCY);}
	}
	
	@PutMapping("/modificacitta2")
	public ResponseEntity ModificaCitta2(@Valid @RequestBody ModificaCittaRequestDTO dto) throws NotFoundException {
		as.modificaCitta2(dto);
		return ResponseEntity.ok("citta modificata");
	
	}
	@PutMapping("/modificacitta3")
	public ResponseEntity ModificaCitta3(@Valid @RequestBody ModificaCittaRequestDTO dto) throws NotFoundException {
		as.modificaCitta3(dto);
		return ResponseEntity.ok("citta modificata");
	
	}
}

