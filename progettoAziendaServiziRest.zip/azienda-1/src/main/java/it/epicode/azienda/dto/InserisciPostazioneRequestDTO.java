package it.epicode.azienda.dto;

import it.epicode.azienda.controller.Tipo;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InserisciPostazioneRequestDTO {
	private String codice;
	private String descrizione;
	private int occupanti;
	private Tipo tipo;
	private String nomeEdificio;
	
	
	
}
