package it.epicode.azienda.repository;

import org.springframework.data.repository.CrudRepository;

import it.epicode.azienda.model.Prenotazione;

public interface PrenotazioneRepository extends CrudRepository<Prenotazione, Integer> {

}
