package it.epicode.azienda.repository;

import org.springframework.data.repository.CrudRepository;

import it.epicode.azienda.model.Edificio;

public interface EdificioRepository extends CrudRepository<Edificio, String> {

}
