package it.epicode.film.dto;

import javax.validation.constraints.NotBlank;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ModificaFilmRequestDTO {
	@NotBlank(message = "il campo id deve essere obbligatorio")
	private int id;
	@NotBlank(message = "il campo titolo deve essere obbligatorio")
	private String titolo;
	@NotBlank(message = "il campo anno deve essere obbligatorio")
	private String anno;
	@NotBlank(message = "il campo regista deve essere obbligatorio")
	private String regista;
	@NotBlank(message = "il campo tipo deve essere obbligatorio")
	private String tipo;
	@NotBlank(message = "il campo incasso deve essere obbligatorio")
	private String incasso;
}
