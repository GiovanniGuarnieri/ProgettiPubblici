package it.epicode.film.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class InserisciFilmRequestDTO {
	@NotBlank(message = "il campo titolo è obbligatorio")
	private String titolo;
	@NotBlank(message = "il campo anno è obbligatorio")
	private String anno;
	@NotBlank(message = "il campo regista è obbligatorio")
	private String regista;
	@NotBlank(message = "il campo tipo è obbligatorio")
	private String tipo;
	@NotBlank(message = "il campo incasso è obbligatorio")
	private String incasso;

}
