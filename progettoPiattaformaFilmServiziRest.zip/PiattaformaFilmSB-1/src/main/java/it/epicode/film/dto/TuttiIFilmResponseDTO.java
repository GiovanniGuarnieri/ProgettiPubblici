package it.epicode.film.dto;

import java.util.List;

import it.epicode.film.elencofilm.Film;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class TuttiIFilmResponseDTO {
private int filmTrovati;
List<Film>elencoFilm;
}
