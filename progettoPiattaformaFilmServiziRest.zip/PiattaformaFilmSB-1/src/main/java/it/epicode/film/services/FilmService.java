package it.epicode.film.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import it.epicode.film.dto.CercaFilmPerIdResponseDTO;
import it.epicode.film.dto.CercaFilmPerRegistaResponseDTO;
import it.epicode.film.dto.InserisciFilmRequestDTO;
import it.epicode.film.dto.ModificaFilmRequestDTO;
import it.epicode.film.dto.TuttiIFilmResponseDTO;
import it.epicode.film.elencofilm.Film;
import it.epicode.film.elencofilm.FilmRepository;

@Service
public class FilmService {
	@Autowired
	FilmRepository fr;


	/**
	 * inserimento nel db di un film attraverso il DTO
	 * @param dto
	 * @return
	 */

	public boolean inserisciFilm(InserisciFilmRequestDTO dto) {
		Film f = new Film();


		f.setTitolo(dto.getTitolo());
		f.setAnno(dto.getAnno());
		f.setRegista(dto.getRegista());
		f.setTipo(dto.getTipo());
		String hash = BCrypt.hashpw(dto.getIncasso(), BCrypt.gensalt());
		f.setIncasso(hash);
		fr.save(f);
		return true;
	}






	/**
	 * ricerca di un film nel db attraverso l'id passato in input 
	 * @param id
	 * @return
	 */
	public CercaFilmPerIdResponseDTO trovaTuttiIFilmPerId(int id) {
		CercaFilmPerIdResponseDTO dto = new  CercaFilmPerIdResponseDTO();

		if(fr.existsById(id)) {
			dto.setFilmTrovato( fr.findById(id).get());
			return dto;}
		else {return null;}
	}







	/**
	 * ritorna la lista di tutti i film con il regista passato in input
	 * @param regista
	 * @return
	 */
	public ResponseEntity trovaTuttiIFilmPerRegista(String regista) {
		CercaFilmPerRegistaResponseDTO dto = new  CercaFilmPerRegistaResponseDTO();
		List<Film>lf = fr.findByRegista(regista) ;
		if(lf.size()>0) {
			dto.setRegista(regista);
			dto.setFilmTrovati(lf.size());
			dto.setListaFilm(lf);
			return ResponseEntity.ok(dto);
		}

		else {
			return new ResponseEntity("non esiste nessun film trovato con quel regista", HttpStatus.NOT_FOUND);
		}
	}





	/**
	 * modifica un film presente nel db 
	 * @param dto
	 * @return
	 */
	public boolean ModificaFilm(ModificaFilmRequestDTO dto) {
		if(fr.existsById(dto.getId())) {
			Film f = fr.findById(dto.getId()).get();
			f.setTitolo(dto.getTitolo());
			f.setAnno(dto.getAnno());
			f.setRegista(dto.getRegista());
			f.setTipo(dto.getTipo());
			String hash = BCrypt.hashpw(dto.getIncasso(), BCrypt.gensalt());
			f.setIncasso(hash);
			fr.save(f);
			return true;


		}
		else {return false;

		}
	}







	/**
	 * metodo service per eliminare un film nel db tramite id 
	 * @param id
	 * @return
	 */
	public boolean	EliminaFilmPerId(int id) {
		if(fr.existsById(id)){
			fr.deleteById(id);

			return true;
		}
		else {return false;
		}
	}






	/**
	 * service per il ritorno di tutti i film presenti nel db
	 * @return
	 */
	public TuttiIFilmResponseDTO tuttiIFilm() {
		TuttiIFilmResponseDTO dto = new TuttiIFilmResponseDTO();
		List<Film>lf = (List)fr.findAll();
		if(lf.size()>0) { 
			dto.setFilmTrovati(lf.size());
			dto.setElencoFilm(lf);
			return dto;}
		else {
			new ResponseEntity("Nessun film è presente nel db ",HttpStatus.NOT_FOUND);
			return null;
		}


	}

}




