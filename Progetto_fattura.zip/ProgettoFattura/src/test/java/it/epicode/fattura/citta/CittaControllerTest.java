package it.epicode.fattura.citta;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.fattura.BasicTests;
import it.epicode.fattura.dto.EliminaCittaRequestDTO;
import it.epicode.fattura.dto.InserisciCittaRequestDTO;

public class CittaControllerTest extends BasicTests {

	@Autowired
	InserisciCittaRequestDTO dtoInserimento;

	@Override
	protected String getEntryPoint() {

		return "/citta";
	}

	@Test
	void getAllCitta() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tuttecitta", HttpMethod.GET,getAuthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

	}
	@Test
	void getAllCittaKo() {
		ResponseEntity<String> r = restTemplate.exchange(api() + "/tuttecitta", HttpMethod.GET, getUnauthorizedEntity(),String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}

	@Test
	void inserisciCitta() {
		HttpEntity<InserisciCittaRequestDTO> entity = new HttpEntity<InserisciCittaRequestDTO>(dtoInserimento,getAuthorizedHeaders());
		ResponseEntity<?> r = restTemplate.exchange(api() + "/inseriscicitta", HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}

	
	void inserisciCittaNotFound() {
		InserisciCittaRequestDTO dto = new InserisciCittaRequestDTO();
		dto.setCap("822200213");
		dto.setNazione("italia3");
		dto.setNome("napoli3");
		dto.setProvincia("napoli3");
		HttpEntity<InserisciCittaRequestDTO> entity = new HttpEntity<InserisciCittaRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?> r = restTemplate.exchange(api() + "/inseriscicitta", HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}
	

	@Test
	void inserisciCittaRole() {
		HttpEntity<InserisciCittaRequestDTO> entity = new HttpEntity<InserisciCittaRequestDTO>(dtoInserimento,getUnauthorizedRoleHeaders());
		ResponseEntity<?> r = restTemplate.exchange(api() + "/inseriscicitta", HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	
	
	@Test
	void inserisciCittaKo() {
		HttpEntity<InserisciCittaRequestDTO> entity = new HttpEntity<InserisciCittaRequestDTO>(dtoInserimento);
		ResponseEntity<?> r = restTemplate.exchange(api() + "/inseriscicitta", HttpMethod.POST,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	
	
	@Test
	void eliminaCittaRoleKo() {
		EliminaCittaRequestDTO dto =new EliminaCittaRequestDTO();
		dto.setCap("800213");
		HttpEntity<EliminaCittaRequestDTO> entity = new HttpEntity<EliminaCittaRequestDTO>(dto,getUnauthorizedRoleHeaders());
		ResponseEntity<?> r = restTemplate.exchange(api() + "/eliminacitta", HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	
	@Test
	void eliminaCittaKo() {
		EliminaCittaRequestDTO dto =new EliminaCittaRequestDTO();
		dto.setCap("800213");
		HttpEntity<EliminaCittaRequestDTO> entity = new HttpEntity<EliminaCittaRequestDTO>(dto);
		ResponseEntity<?> r = restTemplate.exchange(api() + "/eliminacitta", HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	}
	
	@Test
	void eliminaCittaRole() {
		EliminaCittaRequestDTO dto = new EliminaCittaRequestDTO();
		dto.setCap("800213");
		HttpEntity<EliminaCittaRequestDTO> entity = new HttpEntity<EliminaCittaRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?> r = restTemplate.exchange(api() + "/eliminacitta", HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	
	@Test
	void eliminaCittaNotFound() {
		EliminaCittaRequestDTO dto = new EliminaCittaRequestDTO();
		dto.setCap("82");
		HttpEntity<EliminaCittaRequestDTO> entity = new HttpEntity<EliminaCittaRequestDTO>(dto,getAuthorizedHeaders());
		ResponseEntity<?> r = restTemplate.exchange(api() + "/eliminacitta", HttpMethod.DELETE,entity,String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.NOT_FOUND);
	}

}
