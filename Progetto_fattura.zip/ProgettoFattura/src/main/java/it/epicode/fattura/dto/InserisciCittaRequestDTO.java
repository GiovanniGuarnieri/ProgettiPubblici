package it.epicode.fattura.dto;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InserisciCittaRequestDTO {
	
	private String cap;
	private String nome;
	private String provincia;
	private String nazione;
	private List<Long>clienti;


}
