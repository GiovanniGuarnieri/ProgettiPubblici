package it.epicode.fattura.model;

public enum Pagamenti {

	RIMESSA_DIRETTA,
	BONIFICO,
	RICEVUTA_BANCARIA;
}
