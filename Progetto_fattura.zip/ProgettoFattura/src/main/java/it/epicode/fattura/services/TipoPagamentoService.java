package it.epicode.fattura.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode.fattura.dto.CercaTuttiITipoPagamentiResponseDTO;
import it.epicode.fattura.dto.EliminaTipoPagamantoRequestDTO;
import it.epicode.fattura.dto.InserisciTipoPagamentoRequestDTO;
import it.epicode.fattura.dto.ModificaTipoPagamentoRequestDTO;
import it.epicode.fattura.errors.NotFoundException;
import it.epicode.fattura.model.Citta;
import it.epicode.fattura.model.Fattura;
import it.epicode.fattura.model.TipoPagamento;
import it.epicode.fattura.repository.FatturaRepository;
import it.epicode.fattura.repository.TipoPagamentoRepository;

@Service
public class TipoPagamentoService {
	@Autowired
	TipoPagamentoRepository tpr;
	@Autowired
	FatturaRepository fr;
	
	public void inserisciTipoPagamento(InserisciTipoPagamentoRequestDTO dto) throws NotFoundException {
		TipoPagamento tp = new TipoPagamento();
		BeanUtils.copyProperties(dto, tp);
		String elencoFattura = dto.getFattura();
		String[]listaIdFattura = elencoFattura.split(",");
		List<Fattura>lf = new ArrayList<Fattura>();
		for(int i = 0; i<listaIdFattura.length; i++) {
			Long idFattura = Long.parseLong(listaIdFattura[i]);
			Fattura f = fr.findById(idFattura).get();
			if(f!=null & !tp.getFattura().contains(f)) {
				f.setTipo_pagamento(tp);
				lf.add(f);
			}
			else {
				 throw new NotFoundException("fattura non trovata");
			}
			tp.setFattura(lf);
			tpr.save(tp);
		}
	}
	
	public void eliminaTipoPagamento( EliminaTipoPagamantoRequestDTO dto ) throws NotFoundException {
		if(tpr.existsById(dto.getId_fattura())) {
	TipoPagamento tp	=	tpr.findById(dto.getId_fattura()).get();
			tpr.delete(tp);
		}
		else {
			throw new NotFoundException("Tipo Pagamento non trovato");
		}
		
	}
	public void modificaTipoPagamento(ModificaTipoPagamentoRequestDTO dto) throws NotFoundException {
		if(tpr.existsById(dto.getId_tipo_pagamento())) {
		TipoPagamento tp = tpr.findById(dto.getId_tipo_pagamento()).get();
		BeanUtils.copyProperties(dto, tp);
		String elencoFattura = dto.getFattura();
		String[]listaIdFattura = elencoFattura.split(",");
		List<Fattura>lf = new ArrayList<Fattura>();
		for(int i = 0; i<listaIdFattura.length; i++) {
			Long idFattura = Long.parseLong(listaIdFattura[i]);
			Fattura f = fr.findById(idFattura).get();
			if(f!=null) {
				f.setTipo_pagamento(tp);
				lf.add(f);
			}
			else {
				 throw new NotFoundException("fattura non trovata");
			}
			tp.setFattura(lf);
			tpr.save(tp);
		}
	}
		else {
			throw new NotFoundException("tipo pagamento non trovato");
		}
	}
	
	
	public CercaTuttiITipoPagamentiResponseDTO tuttiITipoPagamento() throws NotFoundException {
		 CercaTuttiITipoPagamentiResponseDTO dto = new CercaTuttiITipoPagamentiResponseDTO();
			List <TipoPagamento> tpl = (List)tpr.findAll();
			if(tpl.size()>0) {
				dto.setElencoTipoPagamenti(tpl);
				dto.setTipoPagamentiTrovati(tpl.size());
				return dto;
			}
			else {
				throw new NotFoundException(" nessun tipo pagamento non trovata");
			}
	}
	

}
