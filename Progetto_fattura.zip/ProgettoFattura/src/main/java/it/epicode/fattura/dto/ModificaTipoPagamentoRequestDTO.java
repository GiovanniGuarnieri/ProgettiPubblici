package it.epicode.fattura.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ModificaTipoPagamentoRequestDTO {
	private Long id_tipo_pagamento;
	private String descrizione;
	private String tipo_pagamento;
	private String fattura;
	
}
