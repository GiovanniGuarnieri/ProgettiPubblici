package it.epicode.fattura.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import it.epicode.fattura.model.FatturaRighe;

public interface FatturaRigheRepository extends JpaRepository<FatturaRighe, Long> {

}
