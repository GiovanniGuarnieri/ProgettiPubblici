package it.epicode.fattura.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
 @NoArgsConstructor
public class EliminaClienteRequestDTO {

	private Long id;
}
