package it.epicode.fattura.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.fattura.dto.EliminaClienteRequestDTO;
import it.epicode.fattura.dto.InserisciClienteRequestDTO;
import it.epicode.fattura.dto.ModificaClienteRequestDTO;
import it.epicode.fattura.errors.NotFoundException;
import it.epicode.fattura.services.ClienteService;



@RestController
@RequestMapping("/cliente")
public class ClienteController {
	@Autowired
	ClienteService cs;
	
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inserisciAutore" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisciCliente(@Valid @RequestBody InserisciClienteRequestDTO dto) throws NotFoundException {
		cs.inserisciCliente(dto);
			return ResponseEntity.ok("cliente inserito");}
	
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tutticlienti")
	public ResponseEntity tuttiClienti() throws NotFoundException {
		return ResponseEntity.ok(cs.tuttiClienti());
	}
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modificacliente")
	public ResponseEntity modificaCliente(@Valid @RequestBody ModificaClienteRequestDTO dto) throws NotFoundException {
		cs.modificaCliente(dto);
		return ResponseEntity.ok("Cliente modificato");
	}
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/eliminaAutore")
	public ResponseEntity eliminaCliente(@RequestBody EliminaClienteRequestDTO dto ) throws NotFoundException {
		cs.eliminaCliente(dto);
		return ResponseEntity.ok("Cliente eliminato");
	}

}
