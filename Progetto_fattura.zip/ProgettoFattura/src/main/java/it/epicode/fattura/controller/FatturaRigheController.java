package it.epicode.fattura.controller;

public class FatturaRigheController {

}
