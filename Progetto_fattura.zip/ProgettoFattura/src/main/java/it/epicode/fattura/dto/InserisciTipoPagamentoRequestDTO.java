package it.epicode.fattura.dto;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import it.epicode.fattura.model.Pagamenti;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InserisciTipoPagamentoRequestDTO {
	private String descrizione;
	private String tipo_pagamento;
	private String fattura;
	
	
	
}
