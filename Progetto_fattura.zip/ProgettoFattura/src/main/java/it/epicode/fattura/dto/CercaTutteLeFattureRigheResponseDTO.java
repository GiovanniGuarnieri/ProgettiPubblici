package it.epicode.fattura.dto;

import java.util.List;

import it.epicode.fattura.model.FatturaRighe;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CercaTutteLeFattureRigheResponseDTO {
private int fatturaRigheTrovate;
List<FatturaRighe> elencoFatture;
}
