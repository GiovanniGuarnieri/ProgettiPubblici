package it.epicode.fattura.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ModificaFatturaRequestDTO {
	private Long id_fattura;
	private String clienti;
	private String tipo_pagamento;
	private String fattura_righe;

}
