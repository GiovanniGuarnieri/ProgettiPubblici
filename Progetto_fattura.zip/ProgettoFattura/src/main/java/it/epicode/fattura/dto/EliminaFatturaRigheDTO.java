package it.epicode.fattura.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class EliminaFatturaRigheDTO {
	private Long id_fattura_righe;

}
