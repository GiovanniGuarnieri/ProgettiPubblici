package it.epicode.fattura.configtest;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import it.epicode.fattura.dto.InserisciCittaRequestDTO;

@Configuration
@Profile("test")
public class TestConfiguration {
	
	@Bean
	public InserisciCittaRequestDTO getInserisciCittaRequestDTO() {
		InserisciCittaRequestDTO dto = new InserisciCittaRequestDTO();
		dto.setCap("800213");
		dto.setNazione("italia3");
		dto.setNome("napoli3");
		dto.setProvincia("napoli3");
		return dto;
		
	}

}
