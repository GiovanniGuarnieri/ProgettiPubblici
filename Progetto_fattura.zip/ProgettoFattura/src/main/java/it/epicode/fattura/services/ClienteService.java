package it.epicode.fattura.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode.fattura.dto.CercaTuttiIClientiResponseDTO;
import it.epicode.fattura.dto.EliminaClienteRequestDTO;
import it.epicode.fattura.dto.InserisciClienteRequestDTO;
import it.epicode.fattura.dto.ModificaClienteRequestDTO;
import it.epicode.fattura.errors.NotFoundException;
import it.epicode.fattura.model.Citta;
import it.epicode.fattura.model.Cliente;
import it.epicode.fattura.repository.CittaRepository;
import it.epicode.fattura.repository.ClienteRepository;

@Service
public class ClienteService {


	@Autowired
	ClienteRepository cr;
	@Autowired
	CittaRepository crr;

	public void inserisciCliente (InserisciClienteRequestDTO dto) throws NotFoundException {
		Cliente c = new Cliente ();
		BeanUtils.copyProperties(dto, c);
		if(crr.existsById(dto.getCap_citta())) {
			Citta c1 = crr.findById(dto.getCap_citta()).get();
			if(!c1.getCliente().contains(c)) {
				c1.getCliente().add(c);
				c.setCitta(c1);
				cr.save(c);
			}
		}
		else {
			throw new NotFoundException("cliente non trovata");
		}
	}

	public void eliminaCliente (EliminaClienteRequestDTO dto) throws NotFoundException{
		if (cr.existsById(dto.getId())) {
			Cliente c = cr.findById(dto.getId()).get();
			cr.delete(c);
		}
		else {
			throw new  NotFoundException("cliente non trovato");
		}
	}

	public void modificaCliente (ModificaClienteRequestDTO dto) throws NotFoundException {
		if(cr.existsById(dto.getId_cliente())) {
			Cliente c = cr.findById(dto.getId_cliente()).get();
			BeanUtils.copyProperties(dto, c);
			List<Cliente>clienti = new ArrayList<>();
			if(crr.existsById(dto.getCap_citta())) {
				Citta c1 = crr.findById(dto.getCap_citta()).get();
				if(c1.getCliente().contains(c)) {
					clienti.add(c);
					c1.setCliente(clienti);
					c.setCitta(c1);
					cr.save(c);
				}
				if(!c1.getCliente().contains(c)) {
					c1.getCliente().add(c);
					c.setCitta(c1);
					cr.save(c);
				}
			}
			else {
				throw new NotFoundException("citta non trovata");
			}
		}
		else {
			 throw new NotFoundException("cliente non trovato");
		}
	}

	public CercaTuttiIClientiResponseDTO tuttiClienti() throws NotFoundException {
		CercaTuttiIClientiResponseDTO dto = new CercaTuttiIClientiResponseDTO(); 
		List <Cliente> lc = (List)cr.findAll();
		if(lc.size()>0) {
			dto.setClientiTrovati(lc.size());
			dto.setElencoClienti(lc);
			return dto;
		}
		else {
			throw new NotFoundException("nessun cliente trovato");
		}

	}







}
