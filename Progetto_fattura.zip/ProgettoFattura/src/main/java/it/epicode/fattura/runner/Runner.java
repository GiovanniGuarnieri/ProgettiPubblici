package it.epicode.fattura.runner;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import it.epicode.fattura.impl.ERole;
import it.epicode.fattura.impl.Role;
import it.epicode.fattura.impl.User;
import it.epicode.fattura.impl.UserRepository;
import it.epicode.fattura.model.Citta;
import it.epicode.fattura.model.Cliente;
import it.epicode.fattura.model.Fattura;
import it.epicode.fattura.model.FatturaRighe;
import it.epicode.fattura.model.Pagamenti;
import it.epicode.fattura.model.TipoPagamento;
import it.epicode.fattura.repository.CittaRepository;
import it.epicode.fattura.repository.ClienteRepository;
import it.epicode.fattura.repository.FatturaRepository;
import it.epicode.fattura.repository.FatturaRigheRepository;
import it.epicode.fattura.repository.TipoPagamentoRepository;

@Component
public class Runner implements CommandLineRunner {

	@Autowired
	ClienteRepository cr;
	@Autowired
	FatturaRepository fr;
	@Autowired
	FatturaRigheRepository frr;
	@Autowired
	CittaRepository crr;
	@Autowired
	TipoPagamentoRepository tpr;
	@Autowired
	UserRepository ur; 
	@Autowired
	PasswordEncoder encoder;
	
	@Override
	public void run(String... args) throws Exception {
		
		
		
	
		Citta citta = Citta.builder().cap("802c").nome("Napoli").nazione("Italia").provincia("Napoli").cliente(new ArrayList<>()).build();
		Cliente cliente = Cliente.builder().nome("Giovanni").cognome("Guarnieri").indirizzo("Afragola").codice_fiscale("GRRNGGREGG").citta(citta).fattura(new ArrayList<>()).build();
		TipoPagamento tipoPagamento = TipoPagamento.builder().descrizione("pagamento gas").fattura(new ArrayList<>()).tipo_pagamento(Pagamenti.RICEVUTA_BANCARIA).build();
		FatturaRighe fatturaRighe = FatturaRighe.builder().fattura(new ArrayList<>()).descrizione("pagamento gas").prezzo(200.50).quantita(50).build();
		Fattura fattura = Fattura.builder().cliente(cliente).data("30/09/2022").tipo_pagamento(tipoPagamento).fattura_righe(fatturaRighe).build();

		fr.save(fattura);
		
		Set hash = new HashSet<Role>();
		Role admin= Role.builder().roleName(ERole.ROLE_ADMIN).build();
		hash.add(admin);
		Set hash1 = new HashSet<Role>();
		Role user= Role.builder().roleName(ERole.ROLE_USER).build();
		hash1.add(user);
		User u1 = User.builder().username("mauro").password( BCrypt.hashpw("mauro", BCrypt.gensalt())).email("ciaociao@hotmail.it").roles(hash1).accountActive(true).build();
		User u = User.builder().username("giovanni").password(encoder.encode("maurito")).roles(hash).email("ciaocaio@hotmail.it").accountActive(true).build();
		ur.save(u);
		ur.save(u1);

	}

}
