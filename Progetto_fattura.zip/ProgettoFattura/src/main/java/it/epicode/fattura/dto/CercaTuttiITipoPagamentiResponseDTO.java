package it.epicode.fattura.dto;

import java.util.List;


import it.epicode.fattura.model.TipoPagamento;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CercaTuttiITipoPagamentiResponseDTO {
	private int	tipoPagamentiTrovati;
	List<TipoPagamento>elencoTipoPagamenti;

}
