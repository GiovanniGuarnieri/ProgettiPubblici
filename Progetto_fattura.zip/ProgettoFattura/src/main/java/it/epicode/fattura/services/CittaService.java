package it.epicode.fattura.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode.fattura.dto.CercaTutteLeCittaResponseDTO;
import it.epicode.fattura.dto.EliminaCittaRequestDTO;
import it.epicode.fattura.dto.InserisciCittaRequestDTO;
import it.epicode.fattura.errors.ElementAlreadyPresentException;
import it.epicode.fattura.errors.NotFoundException;
import it.epicode.fattura.model.Citta;
import it.epicode.fattura.model.Cliente;
import it.epicode.fattura.repository.CittaRepository;
import it.epicode.fattura.repository.ClienteRepository;

@Service
public class CittaService {
	
	@Autowired
	CittaRepository cr;
	@Autowired
	ClienteRepository crr;
	
	
	public void inserisciCitta(InserisciCittaRequestDTO dto) throws ElementAlreadyPresentException, NotFoundException {
		Citta c = new Citta();
		if(!cr.existsById(dto.getCap())) {
			/**if(crr.findAllById(dto.getClienti()) != null) {
			List<Cliente> clienti = (List)crr.findAllById(dto.getClienti());
			c.getCliente().addAll(clienti);
			c.setCliente(clienti);
			c.getCliente().forEach(cl->cl.setCitta(c));
			for (Cliente cliente : clienti) {
				cliente.setCitta(c);
			}**/
			
		BeanUtils.copyProperties(dto, c);
		cr.save(c);}
		else {
			throw new ElementAlreadyPresentException("citta gia esistente");
		}	
		}
	
	public void eliminaCitta(EliminaCittaRequestDTO dto) throws NotFoundException {
		if(cr.existsById(dto.getCap())) {
			Citta c = cr.findById(dto.getCap()).get();
			cr.delete(c);		
		}
		else {
			throw new NotFoundException("citta non esistente");
		}
	}
	
	public CercaTutteLeCittaResponseDTO cercaTutteLeCitta() throws NotFoundException {
		CercaTutteLeCittaResponseDTO dto = new CercaTutteLeCittaResponseDTO();
		List <Citta> c = cr.findAll();
		if(c.size()> 0) {
			dto.setCittaTrovate(c.size());
			dto.setElencoCitta(c);
			return dto;
		}
		else {
			throw new  NotFoundException("nessuna citta trovata");
		}
	
		
	}
	public void modificaCitta(InserisciCittaRequestDTO dto) throws  NotFoundException {
		if(cr.existsById(dto.getCap())) {
		Citta c = cr.findById(dto.getCap()).get();
		BeanUtils.copyProperties(dto, c);
		cr.save(c);}
		else {
			throw new NotFoundException("citta non trovata");
		}	
	}

}
