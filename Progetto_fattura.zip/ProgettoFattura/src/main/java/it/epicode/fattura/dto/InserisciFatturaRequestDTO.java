package it.epicode.fattura.dto;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.media.Schema;
import it.epicode.fattura.model.Cliente;
import it.epicode.fattura.model.FatturaRighe;
import it.epicode.fattura.model.TipoPagamento;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InserisciFatturaRequestDTO {

	static final String DATE_PATTERN ="dd/MM/yyyy";
	static final String DATE_TIME_PATTERN ="dd/MM/yyyy HH:mm:ss";
	
@Schema(example = "20/02/2000", type = "string")	
@JsonFormat(pattern = DATE_PATTERN)
private String data;

	private String clienti;

	private String tipo_pagamento ;
	
	private String fattura_righe;

}
