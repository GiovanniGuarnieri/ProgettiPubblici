package it.epicode.fattura.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class Cliente {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id_cliente;
	private String cognome;
	private String nome;
	private String indirizzo;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "id_citta")
	private	 Citta citta;
	@JsonIgnore
	@OneToMany(mappedBy = "cliente",cascade = CascadeType.ALL)
	private List <Fattura> fattura;
	private String codice_fiscale;
	
	
	
	
	
}
