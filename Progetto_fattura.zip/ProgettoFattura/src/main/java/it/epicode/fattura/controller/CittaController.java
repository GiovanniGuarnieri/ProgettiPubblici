package it.epicode.fattura.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.fattura.dto.EliminaCittaRequestDTO;
import it.epicode.fattura.dto.InserisciCittaRequestDTO;
import it.epicode.fattura.errors.ElementAlreadyPresentException;
import it.epicode.fattura.errors.NotFoundException;
import it.epicode.fattura.services.CittaService;



@RestController
@RequestMapping("/citta")

public class CittaController {

	@Autowired
	CittaService css;
	
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inseriscicitta" )
	public ResponseEntity inserisciCitta(@RequestBody InserisciCittaRequestDTO dto) throws  NotFoundException, ElementAlreadyPresentException {
		css.inserisciCitta(dto);
			return ResponseEntity.ok("citta inserita");}
	
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tuttecitta")
	public ResponseEntity tuttiAutori() throws NotFoundException {
		return ResponseEntity.ok(css.cercaTutteLeCitta());
	}
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/eliminacitta")
	public ResponseEntity eliminaCitta(@RequestBody EliminaCittaRequestDTO dto ) throws NotFoundException {
		css.eliminaCitta(dto);
		return ResponseEntity.ok("citta eliminata");
	}
	

	

}
