package it.epicode.fattura.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.fattura.dto.EliminaFatturaRequestDTO;
import it.epicode.fattura.dto.InserisciFatturaRequestDTO;
import it.epicode.fattura.dto.ModificaFatturaRequestDTO;
import it.epicode.fattura.errors.NotFoundException;
import it.epicode.fattura.services.FatturaService;
;


@RestController
@RequestMapping("/fattura")
public class FatturaController {
	@Autowired
	FatturaService fs;
	
	
	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PostMapping(path = "/inserisciAutore" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisciFattura(@Valid @RequestBody InserisciFatturaRequestDTO dto) throws NotFoundException {
		fs.inserisciFattura(dto);
			return ResponseEntity.ok("fattura inserita");}
	
	
	@PreAuthorize("isAuthenticated()")
	@SecurityRequirement(name = "bearerAuth")
	@GetMapping ("/tuttefatture")
	public ResponseEntity tutteFatture() throws NotFoundException {
		return ResponseEntity.ok(fs.cercaTutteLeFatture());
	}

	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@PutMapping("/modificafattura")
	public ResponseEntity modificaFattursa(@Valid @RequestBody ModificaFatturaRequestDTO dto) throws NotFoundException {
		fs.modificaFattura(dto);
		return ResponseEntity.ok("Fattura modificata");
	}

	@PreAuthorize("hasRole('ADMIN')")
	@SecurityRequirement(name = "bearerAuth")
	@DeleteMapping("/eliminafattura")
	public ResponseEntity eliminaFattura(@RequestBody EliminaFatturaRequestDTO dto ) throws NotFoundException {
		fs.eliminaFattura(dto);
		return ResponseEntity.ok("Fattura eliminata");
	}
	

}
