package it.epicode.fattura.services;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode.fattura.dto.CercaTutteLeFattureResponseDTO;
import it.epicode.fattura.dto.EliminaFatturaRequestDTO;
import it.epicode.fattura.dto.InserisciFatturaRequestDTO;
import it.epicode.fattura.dto.ModificaFatturaRequestDTO;
import it.epicode.fattura.errors.NotFoundException;
import it.epicode.fattura.model.Cliente;
import it.epicode.fattura.model.Fattura;
import it.epicode.fattura.model.FatturaRighe;
import it.epicode.fattura.model.TipoPagamento;
import it.epicode.fattura.repository.ClienteRepository;
import it.epicode.fattura.repository.FatturaRepository;
import it.epicode.fattura.repository.FatturaRigheRepository;
import it.epicode.fattura.repository.TipoPagamentoRepository;

@Service
public class FatturaService {

	@Autowired
	FatturaRepository fr;
	@Autowired
	FatturaRigheRepository frp;
	@Autowired
	ClienteRepository cr;
	@Autowired
	TipoPagamentoRepository tpr;


	public void inserisciFattura(InserisciFatturaRequestDTO dto) throws NotFoundException {
		Fattura fattura = new Fattura();
		BeanUtils.copyProperties(dto, fattura);
		String elencoClienti = dto.getClienti();
		String[]listaIdCliente = elencoClienti.split(",");
		List<Cliente>lc = new ArrayList<Cliente>();
		for(int i = 0; i< listaIdCliente.length; i++) {
			Long idCliente = Long.parseLong(listaIdCliente[i]);
			Cliente cliente = cr.findById(idCliente).get();
			if(cliente !=null) {
				cliente.getFattura().add(fattura);
				lc.add(cliente);
				fattura.setCliente(cliente);
				cr.save(cliente);
			}
			else {
				throw new NotFoundException("cliente non trovato");
			}


		}
		String elencoFatturaRighe = dto.getFattura_righe();
		String[]listaIdFatturaRighe = elencoFatturaRighe.split(",");
		List<FatturaRighe>lfr = new ArrayList<FatturaRighe>();
		for(int i = 0; i< listaIdFatturaRighe.length; i++) {
			Long idFatturaRighe = Long.parseLong(listaIdFatturaRighe[i]);
			FatturaRighe fatturaRighe = frp.findById(idFatturaRighe).get();
			if(fatturaRighe !=null) {
				fatturaRighe.getFattura().add(fattura);
				lfr.add(fatturaRighe);
				fattura.setFattura_righe(fatturaRighe);
				frp.save(fatturaRighe);
			}
			else {
				throw new NotFoundException("fattura righe non trovata");
			}
		}
		String elencoTipoPagamento = dto.getTipo_pagamento();
		String[]listaIdTipoPagamento = elencoTipoPagamento.split(",");
		List<TipoPagamento>ltp = new ArrayList<TipoPagamento>();
		for(int i = 0; i< listaIdTipoPagamento.length; i++) {
			Long idTipoPagamento = Long.parseLong(listaIdTipoPagamento[i]);
			TipoPagamento tipoPagamento = tpr.findById(idTipoPagamento).get();
			if(tipoPagamento !=null) {
				tipoPagamento.getFattura().add(fattura);
				ltp.add(tipoPagamento);
				fattura.setTipo_pagamento(tipoPagamento);
				tpr.save(tipoPagamento);
			}
			else {
				throw new NotFoundException("tipo pagamento non trovato");
			}
			fr.save(fattura);
		}
	}
	public void eliminaFattura(EliminaFatturaRequestDTO dto) throws NotFoundException {
		if(fr.existsById(dto.getId_fattura())) {
		Fattura fattura =	fr.findById(dto.getId_fattura()).get();
			fr.delete(fattura);
		}
		else {
			throw new NotFoundException("fattura non trovata");
		}
	}
	public void modificaFattura(ModificaFatturaRequestDTO dto) throws NotFoundException {
		if(fr.existsById(dto.getId_fattura())) {
		Fattura fattura = fr.findById(dto.getId_fattura()).get();
		BeanUtils.copyProperties(dto, fattura);
		String elencoClienti = dto.getClienti();
		String[]listaIdCliente = elencoClienti.split(",");
		List<Cliente>lc = new ArrayList<Cliente>();
		for(int i = 0; i< listaIdCliente.length; i++) {
			Long idCliente = Long.parseLong(listaIdCliente[i]);
			Cliente cliente = cr.findById(idCliente).get();
			if(cliente !=null) {
				cliente.getFattura().add(fattura);
				lc.add(cliente);
			}
			else {
				throw new NotFoundException("cliente non trovato");
			}


		}
		String elencoFatturaRighe = dto.getFattura_righe();
		String[]listaIdFatturaRighe = elencoFatturaRighe.split(",");
		List<FatturaRighe>lfr = new ArrayList<FatturaRighe>();
		for(int i = 0; i< listaIdFatturaRighe.length; i++) {
			Long idFatturaRighe = Long.parseLong(listaIdFatturaRighe[i]);
			FatturaRighe fatturaRighe = frp.findById(idFatturaRighe).get();
			if(fatturaRighe !=null) {
				fatturaRighe.getFattura().add(fattura);
				lfr.add(fatturaRighe);
			}
			else {
				throw new NotFoundException("fattura righe non trovata");
			}
		}
		String elencoTipoPagamento = dto.getTipo_pagamento();
		String[]listaIdTipoPagamento = elencoTipoPagamento.split(",");
		List<TipoPagamento>ltp = new ArrayList<TipoPagamento>();
		for(int i = 0; i< listaIdTipoPagamento.length; i++) {
			Long idTipoPagamento = Long.parseLong(listaIdTipoPagamento[i]);
			TipoPagamento tipoPagamento = tpr.findById(idTipoPagamento).get();
			if(tipoPagamento !=null) {
				tipoPagamento.getFattura().add(fattura);
				ltp.add(tipoPagamento);
			}
			else {
				throw new NotFoundException("tipo pagamento non trovato");
			}
			fr.save(fattura);
		}
	}
		else {
			throw new NotFoundException("fattura non trovata");
		}
	}
	
	
	public CercaTutteLeFattureResponseDTO cercaTutteLeFatture() throws NotFoundException {
		CercaTutteLeFattureResponseDTO dto = new CercaTutteLeFattureResponseDTO();
		List<Fattura>lf = (List)fr.findAll();
		if(lf.size()>0) {
			dto.setFattureTrovate(lf.size());
			dto.setElencoFatture(lf);
			return dto;
		}
		else {
			throw new  NotFoundException("nessuna fattura Trovata");
		}
	}


}