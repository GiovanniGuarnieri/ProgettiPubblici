package it.epicode.fattura.dto;

import java.util.List;

import it.epicode.fattura.model.Fattura;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class CercaTutteLeFattureResponseDTO {
private int fattureTrovate;
List<Fattura>elencoFatture;
}
