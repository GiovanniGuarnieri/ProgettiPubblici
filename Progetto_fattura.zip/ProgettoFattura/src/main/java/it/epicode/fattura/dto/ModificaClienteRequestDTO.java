package it.epicode.fattura.dto;

import org.springframework.data.repository.NoRepositoryBean;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ModificaClienteRequestDTO {
	private Long id_cliente;
	private String cognome;
	private String nome;
	private String indirizzo;
	private String cap_citta;
}
