package it.epicode.fattura.dto;



import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InserisciFatturaRigheDTO {
	
	
	private String descrizione;
	private int quantita;
	private double prezzo;

}
