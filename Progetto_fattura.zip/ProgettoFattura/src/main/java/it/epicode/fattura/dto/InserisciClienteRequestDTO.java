package it.epicode.fattura.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InserisciClienteRequestDTO {
	private String cognome;
	private String nome;
	private String indirizzo;
	private String cap_citta;
	private String codiceFiscale;
}
