package it.epicode.fattura.impl;

public enum ERole {
	ROLE_USER,
	ROLE_ADMIN
	;
}
