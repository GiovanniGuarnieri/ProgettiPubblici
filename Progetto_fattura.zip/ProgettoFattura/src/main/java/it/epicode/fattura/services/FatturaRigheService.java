package it.epicode.fattura.services;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode.fattura.dto.CercaTutteLeFattureRigheResponseDTO;
import it.epicode.fattura.dto.EliminaFatturaRigheDTO;
import it.epicode.fattura.dto.InserisciFatturaRigheDTO;
import it.epicode.fattura.dto.ModificaFatturaRigheDTO;
import it.epicode.fattura.errors.NotFoundException;
import it.epicode.fattura.model.FatturaRighe;
import it.epicode.fattura.repository.FatturaRigheRepository;

@Service
public class FatturaRigheService {
	
	@Autowired
	FatturaRigheRepository frp;
	
	
	
	public void inserisciFatturaRighe(InserisciFatturaRigheDTO dto) {
		FatturaRighe fr = new FatturaRighe();
		BeanUtils.copyProperties(dto, fr);
		frp.save(fr);
		
	}
	
	public void modificaFatturaRighe(ModificaFatturaRigheDTO dto) throws NotFoundException {
		if(frp.existsById(dto.getId_fattura_righe())) {
		FatturaRighe fr = frp.findById(dto.getId_fattura_righe()).get();
		BeanUtils.copyProperties(dto, fr);
		frp.save(fr);
		}
		else {
			throw  new NotFoundException("fatturaRighe non trovata");
		}
		
	}
	
	
	public void eliminaFatturaRighe(EliminaFatturaRigheDTO dto) throws NotFoundException {
		if(frp.existsById(dto.getId_fattura_righe())) {
			FatturaRighe fr = frp.findById(dto.getId_fattura_righe()).get();
			frp.delete(fr);}
		else {
			throw new NotFoundException("fatturaRighe non trovata");
		}
	}
	
	public CercaTutteLeFattureRigheResponseDTO tutteLeFattureRighe() throws NotFoundException {
		CercaTutteLeFattureRigheResponseDTO dto = new CercaTutteLeFattureRigheResponseDTO();
		List<FatturaRighe>lfr=(List)frp.findAll();
		if(lfr.size()>0) {
			dto.setFatturaRigheTrovate(lfr.size());
			dto.setElencoFatture(lfr);
			return dto;
		
		}
		else {
			throw new NotFoundException("nessun Fattura righe trovata");
		}
	}

}
