package it.epicode.fattura.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import it.epicode.fattura.model.Citta;

public interface CittaRepository extends JpaRepository<Citta, String> {

}
