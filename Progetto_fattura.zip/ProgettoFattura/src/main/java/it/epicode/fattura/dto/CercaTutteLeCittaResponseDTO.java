package it.epicode.fattura.dto;

import java.util.List;

import it.epicode.fattura.model.Citta;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class CercaTutteLeCittaResponseDTO {

	
	private int cittaTrovate;
	List<Citta>elencoCitta;
}
